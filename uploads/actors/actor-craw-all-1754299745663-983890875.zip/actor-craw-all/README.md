# Multi-Website Product Crawler

Crawler linh hoạt để cào dữ liệu sản phẩm từ nhiều website khác nhau, hỗ trợ cả website đã biết và website chưa biết.

## 🚀 Tính năng

- **Website đã biết**: Hỗ trợ 20+ website với logic tối ưu riêng
- **Website chưa biết**: Router generic với cấu hình linh hoạt
- **API nội bộ**: Hỗ trợ cả GET và POST API
- **Phân trang**: Tự động phát hiện và xử lý phân trang
- **Lọc link**: Thông minh lọc link sản phẩm
- **Extract data**: Lấy title, description, price, SKU, content, images

## 📋 Cài đặt

```bash
npm install
```

## 🎯 Cách sử dụng

### 1. Website đã biết (có router riêng)

Sử dụng `shopUrl` để crawler tự động nhận diện website:

```json
{
    "shopUrl": "https://vn.toto.com/ban-cau-ve-sinh/",
    "pageStart": 1,
    "pageEnd": 5,
    "delayMin": 1000,
    "delayMax": 3000
}
```

**Các website được hỗ trợ:**
- `vn.toto.com` - TOTO Vietnam
- `lecaophattiles.vn` - Lecaophattiles
- `gachcaocapkhanhhuyen.com` - Gạch cao cấp Khánh Huyền
- `alibaba.com` - Alibaba
- `inax.com.vn` - INAX
- Và 15+ website khác...

### 2. Website chưa biết (router generic)

Sử dụng `startUrls` với `userData` để cấu hình linh hoạt:

```json
{
    "startUrls": [
        {
            "url": "https://example.com/category",
            "userData": {
                "productLinkSelector": ".product-item a",
                "productLinkPattern": "product",
                "paginationPattern": "?page=",
                "maxPages": 10,
                "titleClass": ".product-title",
                "descriptionClass": ".product-description",
                "priceClass": ".product-price",
                "contentClass": ".product-content",
                "autoGenerateSku": true,
                "websiteName": "EXAMPLE"
            }
        }
    ]
}
```

**Kết quả SKU tự động:**
- URL: `https://example.com/product/bon-cau-ve-sinh-thong-minh`
- Title: `Bồn cầu vệ sinh thông minh TOTO`
- SKU được tạo: `EXAMPLE_BON_1234`

## 🔧 Cấu hình chi tiết

### A. Cấu hình cơ bản

#### `productLinkSelector` (CSS Selector)
Selector để tìm link sản phẩm trên trang danh mục:
```json
"productLinkSelector": ".image-fade_in_back a"
```

#### `productLinkPattern` (String)
Pattern để nhận diện link sản phẩm (ưu tiên hơn selector):
```json
"productLinkPattern": "/san-pham/"
```

#### `paginationPattern` (String)
Pattern để tạo URL phân trang:
```json
"paginationPattern": "?page="    // ?page=2, ?page=3
"paginationPattern": "/page/"    // /page/2/, /page/3/
"paginationPattern": "&page="    // &page=2, &page=3
"paginationPattern": "/trang/"   // /trang/2/, /trang/3/
```

#### `maxPages` (Number)
Số trang tối đa để crawl (mặc định: 10)

### B. Cấu hình API nội bộ

#### GET API (như TOTO)
```json
{
    "startUrls": [
        {
            "url": "https://vn.toto.com/ban-cau-ve-sinh/",
            "userData": {
                "apiConfig": {
                    "baseUrl": "https://vn.toto.com/wp-admin/admin-ajax.php",
                    "method": "GET",
                    "fixedParams": {
                        "action": "view_more_product"
                    },
                    "paramSelectors": {
                        "termId": "input#termId"
                    },
                    "pageParam": "page",
                    "maxPages": 20,
                    "delay": 500,
                    "linkSelector": "a",
                    "headers": {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                    }
                },
                "productLinkPattern": "https://vn.toto.com/",
                "titleClass": ".view__desc",
                "descriptionClass": ".product-logictic",
                "priceClass": ".price_load.view__info-price",
                "skuClass": ".view__title",
                "contentClass": ".product-content"
            }
        }
    ]
}
```

#### POST API (như Lecaophattiles)
```json
{
    "startUrls": [
        {
            "url": "http://lecaophattiles.vn/san-pham/apodio-9",
            "userData": {
                "apiConfig": {
                    "baseUrl": "http://lecaophattiles.vn/paging_ajax/ajax_paging.php",
                    "method": "POST",
                    "fixedParams": {
                        "kichthuoc": "0",
                        "sapxep": "0",
                        "list": ""
                    },
                    "paramSelectors": {
                        "danhmuc": "regex:-([0-9]+)(?:[/?#]|$)"
                    },
                    "pageParam": "page",
                    "maxPages": 50,
                    "delay": 1000,
                    "linkSelector": "a[href*=\"san-pham/\"]",
                    "headers": {
                        "User-Agent": "Mozilla/5.0",
                        "Content-Type": "application/x-www-form-urlencoded",
                        "X-Requested-With": "XMLHttpRequest"
                    }
                },
                "productLinkPattern": "san-pham/",
                "titleClass": "ul.product_info li.ten",
                "priceClass": ".price, .product-price",
                "skuClass": "ul.product_info li",
                "contentClass": "div.tab"
            }
        }
    ]
}
```

### C. Cấu hình API nội bộ chi tiết

#### `apiConfig.baseUrl` (String)
URL endpoint của API nội bộ

#### `apiConfig.method` (String)
HTTP method: "GET" hoặc "POST" (mặc định: "GET")

#### `apiConfig.fixedParams` (Object)
Các tham số cố định gửi lên API:
```json
"fixedParams": {
    "action": "view_more_product",
    "category": "toilets"
}
```

#### `apiConfig.paramSelectors` (Object)
Cách lấy tham số động từ trang:

**Lấy từ element:**
```json
"paramSelectors": {
    "termId": "input#termId",
    "categoryId": ".category-selector"
}
```

**Lấy từ URL bằng regex:**
```json
"paramSelectors": {
    "danhmuc": "regex:-([0-9]+)(?:[/?#]|$)",
    "category": "regex:category/([a-z-]+)"
}
```

#### `apiConfig.pageParam` (String)
Tên tham số cho số trang (mặc định: "page")

#### `apiConfig.maxPages` (Number)
Số trang tối đa cho API (mặc định: 10)

#### `apiConfig.delay` (Number)
Delay giữa các request API (milliseconds)

#### `apiConfig.linkSelector` (String)
CSS selector để tìm link sản phẩm trong response API

#### `apiConfig.headers` (Object)
Headers tùy chỉnh cho request API

### D. Cấu hình extract data

#### `titleClass` (String)
CSS selector cho title sản phẩm (hỗ trợ multiple selectors):
```json
"titleClass": ".product-title.product_title.entry-title"
```

#### `descriptionClass` (String)
CSS selector cho description sản phẩm:
```json
"descriptionClass": ".product-description"
```

**Lưu ý:** Nếu không truyền `descriptionClass` hoặc để rỗng, trường `description` sẽ trả về chuỗi rỗng.

#### `priceClass` (String)
CSS selector cho price sản phẩm

#### `skuClass` (String)
CSS selector cho SKU sản phẩm

#### `contentClass` (String)
CSS selector cho content sản phẩm (HTML)

#### `thumbnailClass` (String)
CSS selector cho thumbnail/ảnh đại diện sản phẩm:
```json
"thumbnailClass": ".product-image img"
```

**Hỗ trợ:**
- `src` attribute từ thẻ `<img>`
- `data-src` attribute (lazy loading)
- `background-image` từ CSS style
- Tự động chuyển URL tương đối thành tuyệt đối
- Fallback: lấy ảnh đầu tiên từ trang nếu không có selector

#### `imagesClass` (String)
CSS selector cho tất cả ảnh sản phẩm:
```json
"imagesClass": ".swiper-slide img"
```

**Hỗ trợ:**
- Lấy tất cả ảnh khớp selector
- Tự động loại bỏ ảnh trùng lặp
- Hỗ trợ `src`, `data-src`, `background-image`
- Fallback: lấy tất cả ảnh upload (loại bỏ logo, icon, banner)

#### `imageFilters` (Object)
Lọc ảnh theo pattern tùy chỉnh:
```json
"imageFilters": {
    "includePatterns": ["upload", "product", "gach"],
    "excludePatterns": ["thumb", "small", "icon", "logo"],
    "skuInImage": true
}
```

**Logic lọc:**
1. **excludePatterns**: Loại bỏ ảnh chứa pattern này (ưu tiên cao)
2. **includePatterns**: Chỉ lấy ảnh chứa ít nhất 1 pattern này
3. **skuInImage**: Chỉ lấy ảnh chứa SKU trong URL (nếu true)
4. Nếu không có `includePatterns`, lấy tất cả ảnh không bị exclude

#### `autoGenerateSku` (Boolean)
Tự động tạo SKU khi không tìm thấy SKU trên trang:
```json
"autoGenerateSku": true
```

#### `websiteName` (String)
Tên website để tạo prefix cho SKU tự động:
```json
"websiteName": "TOTO"
```

#### `isPrice` (Boolean)
Bật/tắt lọc sản phẩm theo giá:
```json
"isPrice": true
```

**Logic:**
- `true`: Chỉ lấy sản phẩm có giá (bỏ qua sản phẩm không có giá)
- `false`: Lấy tất cả sản phẩm (có giá hoặc không có giá)

#### `supplier` (String)
Tên nhà cung cấp/supplier:
```json
"supplier": "DAISAN"
```

#### `url_supplier` (String)
URL website của nhà cung cấp:
```json
"url_supplier": "https://b2b.daisan.vn"
```

**Lưu ý:** Cả hai trường này sẽ được thêm vào mỗi sản phẩm được crawl.

**Cách tạo SKU tự động:**
- Format: `WEBSITE_TITLEHASH_NUMBER`
- Ví dụ: `TOTO_BON_1234`
- Độ dài: 15-20 ký tự
- Đảm bảo tính nhất quán cho cùng một sản phẩm

## 📝 Ví dụ thực tế

### Ví dụ 1: Website thông thường
```json
{
    "startUrls": [
        {
            "url": "https://gachcaocapkhanhhuyen.com/san-pham/?filter_kich-thuoc=1000x1000",
            "userData": {
                "productLinkSelector": ".image-fade_in_back a",
                "productLinkPattern": "/san-pham/",
                "paginationPattern": "?page=",
                "maxPages": 10,
                "titleClass": ".product-title.product_title.entry-title",
                "descriptionClass": ".product-logictic.logistic-item",
                "priceClass": ".price",
                "skuClass": ".product-sku",
                "contentClass": ".product-content"
            }
        }
    ]
}
```

### Ví dụ 2: Website với API nội bộ
```json
{
    "startUrls": [
        {
            "url": "https://vn.toto.com/ban-cau-ve-sinh/",
            "userData": {
                "apiConfig": {
                    "baseUrl": "https://vn.toto.com/wp-admin/admin-ajax.php",
                    "fixedParams": {
                        "action": "view_more_product"
                    },
                    "paramSelectors": {
                        "termId": "input#termId"
                    },
                    "pageParam": "page",
                    "maxPages": 20,
                    "delay": 500,
                    "linkSelector": "a"
                },
                "productLinkPattern": "https://vn.toto.com/",
                "titleClass": ".view__desc",
                "priceClass": ".price_load.view__info-price",
                "skuClass": ".view__title",
                "contentClass": ".product-content"
            }
        }
    ]
}
```

### Ví dụ 3: Website không có SKU - Tự động tạo SKU
```json
{
    "startUrls": [
        {
            "url": "https://example.com/category",
            "userData": {
                "productLinkSelector": ".product-item a",
                "productLinkPattern": "product",
                "paginationPattern": "?page=",
                "maxPages": 10,
                "titleClass": ".product-title",
                "descriptionClass": ".product-description",
                "priceClass": ".product-price",
                "contentClass": ".product-content",
                "autoGenerateSku": true,
                "websiteName": "EXAMPLE",
                "isPrice": true
            }
        }
    ]
}
```

### Ví dụ 4: Chỉ lấy sản phẩm có giá
```json
{
    "startUrls": [
        {
            "url": "https://example.com/category",
            "userData": {
                "titleClass": ".product-title",
                "priceClass": ".product-price",
                "contentClass": ".product-content",
                "autoGenerateSku": true,
                "websiteName": "EXAMPLE",
                "isPrice": true  // Chỉ lấy sản phẩm có giá
            }
        }
    ]
}
```

### Ví dụ 5: Lấy thumbnail với selector tùy chỉnh
```json
{
    "startUrls": [
        {
            "url": "https://example.com/category",
            "userData": {
                "titleClass": ".product-title",
                "priceClass": ".product-price",
                "contentClass": ".product-content",
                "thumbnailClass": ".product-image img",
                "autoGenerateSku": true,
                "websiteName": "EXAMPLE",
                "isPrice": true
            }
        }
    ]
}
```

### Ví dụ 6: Lấy tất cả ảnh sản phẩm
```json
{
    "startUrls": [
        {
            "url": "https://example.com/category",
            "userData": {
                "titleClass": ".product-title",
                "priceClass": ".product-price",
                "contentClass": ".product-content",
                "thumbnailClass": ".image-slider-item img",
                "imagesClass": ".swiper-slide img",
                "autoGenerateSku": true,
                "websiteName": "EXAMPLE",
                "isPrice": true
            }
        }
    ]
}
```

### Ví dụ 7: Lọc ảnh với pattern tùy chỉnh
```json
{
    "startUrls": [
        {
            "url": "https://example.com/category",
            "userData": {
                "titleClass": ".product-title",
                "priceClass": ".product-price",
                "contentClass": ".product-content",
                "thumbnailClass": ".image-slider-item img",
                "imagesClass": ".swiper-slide img",
                "imageFilters": {
                    "includePatterns": ["upload", "product", "gach"],
                    "excludePatterns": ["thumb", "small", "icon", "logo", "banner"]
                },
                "autoGenerateSku": true,
                "websiteName": "EXAMPLE",
                "isPrice": true
            }
        }
    ]
}
```

### Ví dụ 8: Thêm thông tin supplier
```json
{
    "startUrls": [
        {
            "url": "https://example.com/category",
            "userData": {
                "titleClass": ".product-title",
                "priceClass": ".product-price",
                "contentClass": ".product-content",
                "thumbnailClass": ".image-slider-item img",
                "imagesClass": ".swiper-slide img",
                "autoGenerateSku": true,
                "websiteName": "EXAMPLE",
                "isPrice": true,
                "supplier": "EXAMPLE",
                "url_supplier": "https://example.com"
            }
        }
    ]
}
```

### Ví dụ 9: Lọc ảnh theo SKU
```json
{
    "startUrls": [
        {
            "url": "https://example.com/category",
            "userData": {
                "titleClass": ".product-title",
                "priceClass": ".product-price",
                "contentClass": ".product-content",
                "thumbnailClass": ".image-slider-item img",
                "imagesClass": ".swiper-slide img",
                "imageFilters": {
                    "includePatterns": ["upload", "product"],
                    "excludePatterns": ["thumb", "small", "icon", "logo"],
                    "skuInImage": true
                },
                "autoGenerateSku": true,
                "websiteName": "EXAMPLE",
                "isPrice": true,
                "supplier": "EXAMPLE",
                "url_supplier": "https://example.com"
            }
        }
    ]
}
```

**Kết quả:**
- Sản phẩm có giá: ✅ Được lấy
- Sản phẩm không có giá: ❌ Bị bỏ qua

## 🏃‍♂️ Chạy crawler

```bash
npm start
```

## 📊 Kết quả

Dữ liệu được lưu vào:
- `hung.json` - File kết quả chính
- `storage/datasets/default/` - Dataset của Crawlee

### Cấu trúc dữ liệu:
```json
{
    "url": "https://example.com/product/123",
    "title": "Tên sản phẩm",
    "description": "Mô tả sản phẩm",
    "price": "1,500,000 VNĐ",
    "sku": "SKU123",
    "content": "<div>Nội dung chi tiết...</div>",
    "thumbnail": "https://example.com/image1.jpg",
    "images": [
        "https://example.com/image1.jpg",
        "https://example.com/image2.jpg"
    ],
    "supplier": "Tên nhà cung cấp",
    "url_supplier": "https://example.com/"
}
```

## 🔍 Debug và Troubleshooting

### Kiểm tra termId trên trang:
```javascript
// Trong Console browser
document.getElementById('termId').value
$('input#termId').attr('value')
```

### Log debug trong unknown-routes:
```javascript
log.info(`Đang tìm ${paramName} với selector: ${selector}`);
log.info(`Element found: ${element.length > 0}`);
log.info(`Element value: ${element.attr('value')}`);
```

### Lỗi thường gặp:
1. **"Assignment to constant variable"** - Đã sửa trong code
2. **"Không tìm thấy termId"** - Kiểm tra selector hoặc dùng regex
3. **"API trả về lỗi"** - Kiểm tra headers và method

## 📁 Cấu trúc project

```
src/
├── routes/
│   ├── index.js              # Router selector
│   ├── unknown-routes.js     # Router generic
│   ├── toto-routes.js        # Router TOTO
│   ├── lecaophattiles-routes.js # Router Lecaophattiles
│   └── ...                   # Các router khác
├── helpers/
│   ├── website-detector.js   # Website detection
│   ├── content-helper.js     # Content formatting
│   └── data-saver.js         # Data saving
└── main.js                   # Entry point
```

## 🤝 Đóng góp

1. Fork project
2. Tạo feature branch
3. Commit changes
4. Push to branch
5. Tạo Pull Request

## 📄 License

MIT License








<!-- 
//{
        "startUrls": [
                {
                        "url": "https://vn.toto.com/ban-cau-ve-sinh/",
                        "userData": {
                                "apiConfig": {
                                        "baseUrl": "https://vn.toto.com/wp-admin/admin-ajax.php",
                                        "fixedParams": {
                                                "action": "view_more_product"
                                        },
                                        "paramSelectors": {
                                                "termId": "input#termId"
                                        },
                                        "pageParam": "page",
                                        "maxPages": 20,
                                        "delay": 500,
                                        "linkSelector": "a",
                                        "headers": {
                                                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                                                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                                                "Accept-Language": "en-US,en;q=0.5",
                                                "Accept-Encoding": "gzip, deflate",
                                                "Connection": "keep-alive"
                                        }
                                },
                                "productLinkPattern": "https://vn.toto.com/",
                                "titleClass": ".view__desc",
                                "descriptionClass": ".product-logictic",
                                "priceClass": ".price_load.view__info-price",
                                "skuClass": ".view__title",
                                "contentClass": ".product-content",
                                "autoGenerateSku": true,
                                "websiteName": "TOTO",
                                "isPrice": true
                        }
                }
        ]
} -->




<!-- 
{
        "startUrls": [
                {
                        "url": "https://b2b.daisan.vn/products/gach-lat-nen",
                        "userData": {
                                "paginationPattern": "?page=",
                                "maxPages": 10,
                                "productLinkSelector": ".list-item-img a",
                                "productLinkPattern": "/gach-",
                                "titleClass": ".product-detail_title h1",
                                "descriptionClass": ".product-logictic",
                                "priceClass": ".price",
                                "skuClass": "",
                                "contentClass": ".product-description",
                                "thumbnailClass": ".image-slider-item img",
                                "imagesClass": ".swiper-slide img",
                                "imageFilters": {
                                        "includePatterns": [],
                                        "excludePatterns": [
                                                "thumb",
                                                "small",
                                                "icon",
                                                "logo"
                                        ],
                                        "skuInImage": false
                                },
                                "autoGenerateSku": true,
                                "websiteName": "DAISAN",
                                "isPrice": true,
                                "supplier": "DAISAN",
                                "url_supplier": "https://b2b.daisan.vn"
                        }
                }
        ]
} -->