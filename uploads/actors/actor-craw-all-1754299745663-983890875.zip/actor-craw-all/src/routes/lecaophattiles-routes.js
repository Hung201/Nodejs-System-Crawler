import { createCheerioRouter } from 'crawlee';
import fetch from 'node-fetch';
import cheerio from 'cheerio';
import { addScrapedData } from '../helpers/data-saver.js';
import { formatContent } from '../helpers/content-helper.js';

export const config = {
    pageStart: 1,
    pageEnd: 50, // Giới hạn tối đa 50 trang để tránh lặp vô hạn
};

export const router = createCheerioRouter();

router.addDefaultHandler(async ({ request, enqueueLinks, log }) => {
    const url = request.loadedUrl;
    log.info(`+ Lecaophattiles Category: ${url}`);

    // Lấy danhmuc id từ URL (ví dụ: /san-pham/apodio-9 => 9)
    const match = url.match(/-(\d+)(?:[/?#]|$)/);
    if (!match) {
        log.info('Không lấy được danhmuc id từ URL.');
        return;
    }
    const danhmuc = match[1];

    for (let page = config.pageStart; page <= config.pageEnd; page++) {
        const apiUrl = 'http://lecaophattiles.vn/paging_ajax/ajax_paging.php';
        const formData = new URLSearchParams({
            page: page.toString(),
            kichthuoc: '0',
            sapxep: '0',
            danhmuc,
            list: ''
        });
        log.info(`POST API: ${apiUrl} | page=${page} | danhmuc=${danhmuc}`);
        const res = await fetch(apiUrl, {
            method: 'POST',
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Referer': url,
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData.toString()
        });
        if (!res.ok) {
            log.info(`API trả về lỗi hoặc hết trang ở page ${page}`);
            break;
        }
        const html = await res.text();
        const $ = cheerio.load(html);
        let found = false;
        $('a[href*="san-pham/"]').each(function (i, el) {
            const href = $(el).attr('href');
            if (href && (/san-pham\/[a-zA-Z0-9\-_/]+(\.html)?(\?.*)?$/.test(href) || /^https?:\/\/lecaophattiles.vn\/san-pham\/[a-zA-Z0-9\-_/]+(\.html)?(\?.*)?$/.test(href))) {
                const fullUrl = href.startsWith('http') ? href : `http://lecaophattiles.vn/${href.replace(/^\//, '')}`;
                enqueueLinks({
                    label: 'lecaophattiles-detail',
                    strategy: 'same-domain',
                    urls: [fullUrl]
                });
                found = true;
            }
        });
        if (!found) {
            log.info(`Không tìm thấy link sản phẩm ở page ${page}, dừng crawl.`);
            break;
        }
    }
});

// Handler chi tiết sản phẩm
router.addHandler('lecaophattiles-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ Lecaophattiles Detail: ${url}`);
    try {
        // Lấy title sản phẩm
        let title = $('ul.product_info li.ten').first().text().trim();
        if (!title) {
            title = $('h1, .product-title, .entry-title').first().text().trim();
        }
        if (!title) {
            title = $('title').first().text().trim();
        }
        if (!title) {
            log.info('Bỏ qua sản phẩm vì không có title.');
            return;
        }
        // Lấy mô tả
        let description = '';
        // Lấy ảnh đại diện
        // Danh sách ảnh cần loại bỏ
        const imageBlacklist = [
            "http://lecaophattiles.vn/upload/sanpham/160922169_220x220.jpg",
            "http://lecaophattiles.vn/upload/sanpham/160914177_220x220.jpg",
            "http://lecaophattiles.vn/upload/sanpham/160903210_220x220.jpg",
            "http://lecaophattiles.vn/upload/sanpham/10962074_220x220.jpg",
            "http://lecaophattiles.vn/images/dangonl.png",
            "http://lecaophattiles.vn/images/tuan.png",
            "http://lecaophattiles.vn/images/thang.png",
            "http://lecaophattiles.vn/images/tong.png",
            "http://lecaophattiles.vn/images/tong.png",
        ];
        // Lấy tất cả ảnh trong trang (chỉ lấy ảnh có src chứa 'upload/sanpham/' và không thuộc blacklist, không chứa '/thumb/100x80')
        let images = [];
        $('img').each(function (i, el) {
            let src = $(el).attr('src');
            if (src && !src.includes('100x80') && !src.includes('/hinhanh/') && !src.includes('/thumb/100x80') && !src.includes('/images/') && !src.includes('220x220')) {
                if (!src.startsWith('http')) {
                    src = `http://lecaophattiles.vn/${src.replace(/^\//, '')}`;
                }
                if (!images.includes(src) && !imageBlacklist.includes(src)) images.push(src);
            }
        });
        // Thumbnail là ảnh đầu tiên trong images nếu có
        let thumbnail = images.length > 0 ? images[0] : ($('img').first().attr('src') || '');
        if (thumbnail && !thumbnail.startsWith('http')) {
            thumbnail = `http://lecaophattiles.vn/${thumbnail.replace(/^\//, '')}`;
        }
        // Lấy nội dung chi tiết: lấy toàn bộ html của div.tab[style*="display: block"], nếu không có thì lấy div.tab đầu tiên
        let content = $('div.tab[style*="display: block"]').html() || '';
        if (!content) {
            content = $('div.tab').first().html() || '';
        }
        if (!content) {
            content = $('.content, .entry-content, .product-content').html() || '';
        }
        // Lấy giá nếu có
        let price = $('.price, .product-price').first().text().trim() || '';
        // Lấy sku
        let sku = '';
        $('ul.product_info li').each(function (i, el) {
            const label = $(el).find('b').first().text().trim();
            if (/^Mã sản phẩm:?$/i.test(label)) {
                sku = $(el).text().replace(label, '').replace(/['"\s]+/g, '').trim();
            }
        });
        // Push data
        const productData = {
            url,
            title,
            sku,
            description,
            price,
            thumbnail,
            images,
            content: formatContent(content, 'lecao'),
            supplier: 'Lecaophattiles',
            url_supplier: 'http://lecaophattiles.vn/'
        };
        pushData(productData);
        addScrapedData(productData)
        log.info(`Đã lấy xong dữ liệu sản phẩm: ${title}`);
    } catch (err) {
        log.error('Error in lecaophattiles-detail handler:', err.message);
    }
});
