import { createCheerioRouter, sleep } from 'crawlee';
import { createRandomSleep } from '../helpers/crawler-helper.js';
import { formatContent } from '../helpers/content-helper.js';
import he from 'he';

export const config = {
    pageStart: 1,
    pageEnd: 50, // Giới hạn tối đa 50 trang để tránh lặp vô hạn
    delayMin: 500,
    delayMax: 1000,
};

export const router = createCheerioRouter();

// Handler danh mục: enqueue link sản phẩm
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
    const url = request.loadedUrl;
    log.info(`+ Ecobiglaziotile Category: ${url}`);

    // Tìm tất cả link chi tiết sản phẩm trong danh mục
    const productItems = [];

    // Các selector để tìm block sản phẩm
    const productBlockSelectors = [
        '.tp-product-item',
        '.product-item',
        '.product',
        '.col',
    ];

    let foundBlockSelector = '';
    for (const blockSelector of productBlockSelectors) {
        if ($(blockSelector).length > 0) {
            foundBlockSelector = blockSelector;
            break;
        }
    }

    if (foundBlockSelector) {
        $(foundBlockSelector).each(function (i, el) {
            // Tìm link sản phẩm trong block
            let linkEl = $(el).find('a[href*="/product"]');
            if (!linkEl.length) linkEl = $(el).find('a');
            const href = linkEl.attr('href');
            if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
                const fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
                if (fullUrl.includes('/product')) {
                    // Tìm thumbnail trong block
                    let thumbImg = $(el).find('img');
                    let thumbnail = '';
                    if (thumbImg.length) {
                        thumbnail = thumbImg.first().attr('src') || '';
                    }
                    productItems.push({ url: fullUrl, thumbnail });
                }
            }
        });
    }

    if (productItems.length > 0) {
        log.info(`Tìm thấy ${productItems.length} sản phẩm với block selector: ${foundBlockSelector}`);
    } else {
        // Fallback: logic cũ nếu không tìm thấy block
        const productLinks = new Set();
        const selectors = [
            'a.product-title',
            'a[href*="/products/"]',
            'a[href*="/product/"]',
            '.product-item a',
            '.product a',
            'h2 a',
            'h3 a'
        ];
        for (const selector of selectors) {
            $(selector).each(function (i, el) {
                const href = $(el).attr('href');
                if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
                    const fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
                    if (fullUrl.includes('/product') || fullUrl.includes('/products')) {
                        productLinks.add(fullUrl);
                    }
                }
            });
            if (productLinks.size > 0) {
                log.info(`Tìm thấy ${productLinks.size} link sản phẩm với selector: ${selector}`);
                break;
            }
        }
        for (const url of productLinks) {
            productItems.push({ url, thumbnail: '' });
        }
    }

    log.info(`Tổng cộng tìm thấy ${productItems.length} sản phẩm.`);

    if (productItems.length > 0) {
        // Enqueue từng link sản phẩm kèm thumbnail
        for (const item of productItems) {
            await enqueueLinks({
                urls: [item.url],
                label: 'ecobiglaziotile-detail',
                strategy: 'same-domain',
                userData: { thumbnail: item.thumbnail }
            });
        }

        // Logic phân trang
        const urlObj = new URL(url);
        let currentPage = parseInt(urlObj.searchParams.get('page') || '1', 10);
        if (currentPage < config.pageEnd) {
            const nextPage = currentPage + 1;
            urlObj.searchParams.set('page', nextPage);
            const nextPageUrl = urlObj.toString();
            log.info(`Enqueue trang tiếp theo: ${nextPageUrl} (trang ${nextPage}/${config.pageEnd})`);
            await enqueueLinks({ urls: [nextPageUrl] });
        } else {
            log.info(`Đã đạt giới hạn trang tối đa (${config.pageEnd}). Dừng phân trang.`);
        }
    } else {
        log.info('Không tìm thấy link sản phẩm nào. Có thể đã hết trang hoặc cấu trúc website thay đổi.');
    }
});

// Handler chi tiết sản phẩm
router.addHandler('ecobiglaziotile-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ Ecobiglaziotile Detail: ${url}`);

    try {
        // Title: lấy từ h1.tp-product-details-title
        let title = $('h1.tp-product-details-title').first().text().trim();
        if (!title) {
            // Fallback: h1
            title = $('h1').first().text().trim();
        }
        if (!title) {
            log.info('Bỏ qua sản phẩm vì không có title.');
            return;
        }

        // Description: lấy từ .tp-product-details-description span
        let description = $('.tp-product-details-description span').first().text().trim();
        if (!description) {
            // Fallback: .tp-product-details-description
            description = $('.tp-product-details-description').first().text().trim();
        }
        if (!description) {
            // Fallback: meta description
            description = $('meta[name="description"]').attr('content') || '';
        }

        // Price: lấy từ span.tp-product-details-price.new-price
        let price = $('span.tp-product-details-price.new-price').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
        if (!price) {
            // Fallback: .tp-product-details-price
            price = $('.tp-product-details-price').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
        }
        if (!price) {
            // Fallback: .price
            price = $('.price').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
        }

        // SKU: lấy từ <span data-bb-value="product-sku"> (ưu tiên), nếu không có thì các cách cũ
        let sku = $('span[data-bb-value="product-sku"]').first().text().trim();
        if (!sku) {
            sku = $('span[data-tpb-value="product_sku"]').first().text().trim();
        }
        if (!sku) {
            sku = $('span.tp-product-details-query-item[data-tpb-value="product_sku"]').first().text().trim();
        }
        if (!sku) {
            $('span.tp-product-details-query-item').each(function (i, el) {
                const txt = $(el).text().trim();
                if (txt.length > 10 && txt.includes('-')) {
                    sku = txt;
                    return false;
                }
            });
        }
        if (!sku) {
            // Fallback: lấy từ URL
            const urlParts = url.split('/');
            sku = urlParts[urlParts.length - 1] || '';
        }

        // Categories: lấy text của <a> trong div.tp-product-details-query-item chứa span:contains('Category:')
        let categories = [];
        $(".tp-product-details-query-item").each(function (i, el) {
            const label = $(el).find('span').first().text().trim();
            if (/^Category:?$/i.test(label)) {
                $(el).find('a').each(function (j, a) {
                    const txt = $(a).text().trim();
                    if (txt) categories.push(txt);
                });
            }
        });

        // Tags: lấy text của tất cả <a> trong div.tp-product-details-query-item chứa span:contains('Tag:')
        let tags = [];
        $(".tp-product-details-query-item").each(function (i, el) {
            const label = $(el).find('span').first().text().trim();
            if (/^Tag:?$/i.test(label)) {
                $(el).find('a').each(function (j, a) {
                    const txt = $(a).text().trim();
                    if (txt) tags.push(txt);
                });
            }
        });

        // Images: lấy tất cả src của img có src chứa '/storage/' nhưng bỏ logo
        let images = [];
        $('img').each(function (i, el) {
            const src = $(el).attr('src');
            if (src && src.includes('/storage/') && !/logo/i.test(src) && !/footer-pay/i.test(src)) {
                images.push(src);
            }
        });

        // Fallback: lấy tất cả ảnh sản phẩm
        if (images.length === 0) {
            $('img').each(function (i, el) {
                const src = $(el).attr('src');
                if (src && !/logo/i.test(src) && !/footer-pay/i.test(src) && !/banner/i.test(src)) {
                    images.push(src);
                }
            });
        }

        images = Array.from(new Set(images)); // Loại bỏ duplicate

        // Content: lấy html của div.tp-product-details-desc-wrapper và xử lý bằng formatContent
        let content = $('.tp-product-details-desc-wrapper').html() || '';
        if (!content) {
            // Fallback: lấy từ .product-description
            content = $('.product-description').html() || '';
        }
        if (!content) {
            // Fallback: lấy từ .description
            content = $('.description').html() || '';
        }
        content = he.decode(content);
        content = formatContent(content, 'ecobiglaziotile');

        // Thumbnail: lấy từ userData nếu có, nếu không thì fallback như cũ
        let thumbnail = request.userData && request.userData.thumbnail ? request.userData.thumbnail : '';
        if (!thumbnail) {
            const thumbImg = $('div.tp-product-thumb-4.w-img.fix img').first();
            if (thumbImg.length) {
                thumbnail = thumbImg.attr('src') || '';
            }
        }

        const productData = {
            sku,
            url,
            title,
            description,
            price,
            categories,
            tags,
            thumbnail,
            images,
            content,
            supplier: 'Ecobiglaziotile',
            url_supplier: 'https://ecobiglaziotile.com'
        };

        pushData(productData);
        log.info(`Đã lấy xong dữ liệu sản phẩm: ${title}`);

    } catch (err) {
        log.error('Error in ecobiglaziotile-detail handler:', err.message);
    }

    await sleep(createRandomSleep(config.delayMin, config.delayMax));
}); 