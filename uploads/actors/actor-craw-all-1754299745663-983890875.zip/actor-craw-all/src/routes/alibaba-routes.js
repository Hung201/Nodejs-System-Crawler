import { createCheerioRouter, sleep } from 'crawlee';
import { createRandomSleep, getBaseUrl, getProductIdFromUrl, createProductDescUrl, productDetailPatternUrl } from '../helpers/crawler-helper.js';
import { formatContent } from '../helpers/content-helper.js';
import { getProductData } from '../extracts/product-extract.js';
import { addScrapedData } from '../helpers/data-saver.js';

export const config = {
    pageStart: 1,
    pageEnd: 1,
    delayMin: 500,
    delayMax: 1000,
};

// dùng database lưu trạng thái đã chạy, đang chạy page nào, dừng ở đâu
// hoặc lưu các link đã chạy

const state = {
    page: config.pageStart
};

export const router = createCheerioRouter();

const findProductLinks = async (enqueueLinks, urls = []) => {
    const data = {};
    if (urls && urls.length > 0) {
        data.urls = urls;
    }
    else {
        data.globs = [productDetailPatternUrl()];
    }

    await enqueueLinks({
        label: 'detail',
        strategy: 'same-domain',
        ...data
    });
};

const addNextProductList = async (enqueueLinks, request) => {
    if (state.page <= config.pageEnd) {
        const baseUrl = getBaseUrl(request.loadedUrl);
        // Thử nhiều pattern URL khác nhau cho Alibaba
        const productListUrls = [
            `${baseUrl}/productlist-${state.page}.html`,
            `${baseUrl}/products-${state.page}.html`,
            `${baseUrl}/search?page=${state.page}`,
            `${baseUrl}/products?page=${state.page}`
        ];

        await enqueueLinks({
            label: 'product-list',
            strategy: 'same-domain',
            urls: productListUrls
        });

        state.page += 1;
    }
};

router.addDefaultHandler(async ({ request, enqueueLinks, log }) => {
    log.info(`+ Start: ${request.loadedUrl}`);

    await addNextProductList(enqueueLinks, request);
});

router.addHandler('product-list', async ({ request, enqueueLinks, $, log }) => {
    log.info(`+ Product List: ${request.loadedUrl}`);

    try {
        // Thử nhiều cách khác nhau để lấy danh sách sản phẩm
        let productListUrl = [];

        // Cách 1: Tìm module data
        const $muduleProductListElement = $('div[module-title="productListPc"]');
        if ($muduleProductListElement.length > 0) {
            try {
                const moduleProductListJson = decodeURIComponent($muduleProductListElement.attr('module-data'));
                const moduleProductList = JSON.parse(moduleProductListJson);
                const productListSrc = moduleProductList?.mds?.moduleData?.data?.productList || [];
                productListUrl = productListSrc.map((item) => item.url);
                log.info(`Found ${productListUrl.length} products via module-data`);
            } catch (err) {
                log.error('Error parsing module-data:', err.message);
            }
        }

        // Cách 2: Tìm links sản phẩm trực tiếp
        if (productListUrl.length === 0) {
            const productLinks = $('a[href*="/product-detail/"]').map((i, el) => $(el).attr('href')).get();
            productListUrl = productLinks.map(link => {
                if (link.startsWith('/')) {
                    return getBaseUrl(request.loadedUrl) + link;
                }
                return link;
            });
            log.info(`Found ${productListUrl.length} products via direct links`);
        }

        // Cách 3: Tìm trong script tags
        if (productListUrl.length === 0) {
            $('script').each((i, el) => {
                const text = $(el).html();
                if (text && text.includes('productList')) {
                    try {
                        const match = /productList\s*:\s*(\[.*?\])/s.exec(text);
                        if (match) {
                            const products = JSON.parse(match[1]);
                            productListUrl = products.map(p => p.url || p.href).filter(Boolean);
                            log.info(`Found ${productListUrl.length} products via script`);
                        }
                    } catch (err) {
                        log.error('Error parsing script productList:', err.message);
                    }
                }
            });
        }

        // Cách 4: Tìm tất cả links có pattern product-detail
        if (productListUrl.length === 0) {
            const allLinks = $('a').map((i, el) => $(el).attr('href')).get();
            productListUrl = allLinks.filter(link =>
                link && link.includes('/product-detail/')
            ).map(link => {
                if (link.startsWith('/')) {
                    return getBaseUrl(request.loadedUrl) + link;
                }
                return link;
            });
            log.info(`Found ${productListUrl.length} products via all links`);
        }

        if (productListUrl.length > 0) {
            await findProductLinks(enqueueLinks, productListUrl);
        } else {
            log.warning('No products found on this page');
        }
    }
    catch (err) {
        log.error('Error in product-list handler:', err.message);
    }

    await addNextProductList(enqueueLinks, request);
});

router.addHandler('description', async ({ request, json, log }) => {
    log.info(`+ Description: ${request.loadedUrl}`);

    const destProduct = request.userData.destProduct;

    try {
        const htmlDescription = json?.data?.productHtmlDescription || '';
        destProduct.content = formatContent(htmlDescription);
        addScrapedData(destProduct);
        log.info('Successfully added product data');
    }
    catch (err) {
        log.error('Error in description handler:', err.message);
    }

    await sleep(createRandomSleep(config.delayMin, config.delayMax));
});

router.addHandler('detail', async ({ request, enqueueLinks, $, log }) => {
    const url = request.loadedUrl;

    log.info(`+ Detail: ${url}`);

    try {
        let detailData = null;

        // Cách 1: Tìm trong script tag cụ thể
        const $scriptDataElement = $('#layout-other').next();
        if ($scriptDataElement.length > 0) {
            let dataMatch = /window\.detailData\s*=\s*(.+?);\s*window\.detailData/s.exec($scriptDataElement.text());
            if (dataMatch) {
                try {
                    detailData = JSON.parse(dataMatch[1]);
                    log.info('Found detailData via layout-other method');
                } catch (err) {
                    log.error('Error parsing detailData from layout-other:', err.message);
                }
            }
        }

        // Cách 2: Tìm trong tất cả script tags
        if (!detailData) {
            $('script').each((i, el) => {
                const text = $(el).html();
                if (text && text.includes('window.detailData')) {
                    try {
                        const match = /window\.detailData\s*=\s*(\{.*?\});/s.exec(text);
                        if (match) {
                            detailData = JSON.parse(match[1]);
                            log.info('Found detailData via script search method');
                            return false; // break the loop
                        }
                    } catch (err) {
                        log.error('Error parsing detailData from script:', err.message);
                    }
                }
            });
        }

        // Cách 3: Tìm trong JSON-LD
        if (!detailData) {
            $('script[type="application/ld+json"]').each((i, el) => {
                try {
                    const jsonData = JSON.parse($(el).html());
                    if (jsonData && jsonData['@type'] === 'Product') {
                        detailData = { globalData: { product: jsonData } };
                        log.info('Found product data via JSON-LD');
                        return false;
                    }
                } catch (err) {
                    // Ignore JSON parse errors
                }
            });
        }

        if (detailData) {
            const destProduct = getProductData(url, $, detailData);

            const descriptionUrl = createProductDescUrl(getProductIdFromUrl(url));

            await enqueueLinks({
                label: 'description',
                forefront: true,
                strategy: 'same-domain',
                urls: [descriptionUrl],
                transformRequestFunction: (request) => {
                    request.userData.destProduct = destProduct;
                    return request;
                }
            });
        } else {
            log.error('Could not find detailData on product page');
        }
    }
    catch (err) {
        log.error('Error in detail handler:', err.message);
    }

    await sleep(createRandomSleep(config.delayMin, config.delayMax));
});

/*
+ viết API nhận dữ liệu bên B2B
+ xử lý Việt Hóa

*/