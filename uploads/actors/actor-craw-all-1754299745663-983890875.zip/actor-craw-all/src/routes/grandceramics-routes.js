import { createCheerioRouter } from 'crawlee';
import he from 'he';
import { getImagesWithPuppeteer } from '../helpers/puppeteer-image-helper.js';
import { addScrapedData } from '../helpers/data-saver.js';

export const config = {};
export const router = createCheerioRouter();

// Handler danh mục: thu thập link sản phẩm
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
    log.info(`+ GrandCeramics Category: ${request.loadedUrl}`);
    // Tìm tất cả link sản phẩm
    const productLinks = new Set();
    $('a').each(function (i, el) {
        const href = $(el).attr('href');
        if (href && href.includes('/san-pham/') && href.endsWith('.html')) {
            const fullUrl = href.startsWith('http') ? href : new URL(href, request.loadedUrl).href;
            productLinks.add(fullUrl);
        }
    });
    log.info(`Tìm thấy ${productLinks.size} link sản phẩm.`);
    if (productLinks.size > 0) {
        await enqueueLinks({
            label: 'grandceramics-detail',
            strategy: 'same-domain',
            urls: Array.from(productLinks)
        });
    }
});

// Handler chi tiết sản phẩm
// router.addHandler('grandceramics-detail', async ({ request, $, log, pushData }) => {
router.addHandler('grandceramics-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ GrandCeramics Detail: ${url}`);
    // Lấy sku bằng cách ghép các span.char[data-char]
    let sku = '';
    $('h2 span.char[data-char]').each(function (i, el) {
        sku += $(el).attr('data-char') || '';
    });
    sku = sku.trim();
    // Nếu không lấy được sku từ HTML, lấy từ url
    if (!sku) {
        const match = url.match(/\/san-pham\/([a-zA-Z0-9_-]+)\.html/);
        if (match) {
            sku = match[1];
        }
    }
    // Lấy title luôn từ url (giống sku)
    let title = '';
    const match = url.match(/\/san-pham\/([a-zA-Z0-9_-]+)\.html/);
    if (match) {
        title = match[1];
    }
    // Lấy images bằng puppeteer
    let images = await getImagesWithPuppeteer(url);
    if (sku) {
        images = images.filter(img => img.toLowerCase().includes(sku.toLowerCase()));
    }
    // Nếu không có ảnh thì bỏ qua sản phẩm này
    if (!images || images.length === 0) return;

    // Lấy thumbnail từ images[0]
    let thumbnail = images.length > 0 ? images[0] : '';

    // Lấy content là HTML của .content-main.pro-intro nếu có
    let content = '';
    const introElem = $('.content-main.pro-intro');
    if (introElem.length) {
        content = introElem.html();
        // Format content với style grandceramic
        const { formatContent } = await import('../helpers/content-helper.js');
        content = formatContent(content, 'grandceramic');
    }
    pushData({ url, sku, title, thumbnail, images, content, supplier: 'GrandCeramics', url_supplier: 'https://grandceramics.vn' });
    // addScrapedData({ url, sku, title, thumbnail, images, content, supplier: 'GrandCeramics', url_supplier: 'https://grandceramics.vn' });
}); 