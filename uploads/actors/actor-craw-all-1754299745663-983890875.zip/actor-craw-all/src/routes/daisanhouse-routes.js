import { createCheerioRouter } from 'crawlee';
import { formatContent } from '../helpers/content-helper.js';
import he from 'he';
import { addScrapedData } from '../helpers/data-saver.js';

export const config = {};
export const router = createCheerioRouter();

// Biến toàn cục lưu link sản phẩm khi phân trang
const productLinks = new Set();
const MAX_PAGE = 5;

// Handler danh mục: thu thập tất cả link sản phẩm qua các trang, sau đó enqueue chi tiết
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
    log.info(`+ Daisanhouse Category: ${request.loadedUrl}`);
    // Thu thập link sản phẩm
    $('a[href^="/shop/"]').each(function (i, el) {
        const href = $(el).attr('href');
        if (href && !href.includes('/category/')) {
            const fullUrl = href.startsWith('http') ? href : new URL(href, request.loadedUrl).href;
            productLinks.add(fullUrl);
        }
    });
    // Kiểm tra có sản phẩm mới không
    const currentPage = Number(new URL(request.loadedUrl).searchParams.get('page') || 1);
    const hasProduct = $('a[href^="/shop/"]').length > 0;
    if (hasProduct && currentPage < MAX_PAGE) {
        // Tăng page và enqueue tiếp
        const nextPage = currentPage + 1;
        const urlObj = new URL(request.loadedUrl);
        urlObj.searchParams.set('page', nextPage);
        const nextPageUrl = urlObj.toString();
        log.info(`Enqueue page tiếp theo: ${nextPageUrl}`);
        await enqueueLinks({ urls: [nextPageUrl] });
    } else {
        // Không còn sản phẩm mới hoặc đã đạt max page, enqueue chi tiết tất cả link đã thu thập
        log.info(`Đã thu thập đủ link sản phẩm (${productLinks.size}), bắt đầu enqueue chi tiết.`);
        await enqueueLinks({
            label: 'daisanhouse-detail',
            strategy: 'same-domain',
            urls: Array.from(productLinks)
        });
        productLinks.clear(); // Xóa để tránh lặp lại nếu crawl lại
    }
});

// Handler chi tiết sản phẩm: giữ nguyên như cũ
router.addHandler('daisanhouse-detail', async ({ request, $, log }) => {
    const url = request.loadedUrl;
    log.info(`+ Daisanhouse Detail: ${url}`);
    const title = $('h1[itemprop="name"].h3').first().text().trim();
    let description = $('p.text-muted.my-2[placeholder]').first().text().trim();
    if (!description) {
        description = $('#product_details p').first().text().trim();
    }
    // Xóa thẻ <p> và </p> nếu có trong description
    description = description.replace(/<\/?p>/gi, '');
    let price = $('span[itemprop="price"]').first().text().replace(/[^\d.,]/g, '').trim();
    price = price.replace(/([.,]0+)?$/, '');
    let thumbnail = $('div.carousel-item.h-100.active img').first().attr('src') || '';
    if (thumbnail && thumbnail.startsWith('/')) {
        thumbnail = 'https://daisanhouse.vn' + thumbnail;
    }
    let images = [];
    $('div.carousel-inner.h-100 img').each(function (i, el) {
        let src = $(el).attr('src');
        if (src && src.startsWith('/')) {
            src = 'https://daisanhouse.vn' + src;
        }
        if (src && src !== thumbnail && !images.includes(src)) images.push(src);
    });
    // Thêm sku lấy từ cuối title
    let sku = '';
    const skuMatch = title.match(/([A-Z0-9]{5,})$/);
    if (skuMatch) {
        sku = 'DSH-' + skuMatch[1];
    } else {
        // Nếu không có trong title, lấy số cuối cùng trong url
        const urlIdMatch = url.match(/-(\d+)(?:\?|$)/);
        if (urlIdMatch) {
            sku = 'DSH-' + urlIdMatch[1];
        }
    }
    // Lấy content HTML từ #product_full_description và format
    let content = $('#product_full_description').html() || '';
    content = he.decode(content);
    content = formatContent(content, 'daisanhouse');
    if (!title) {
        log.info('Bỏ qua sản phẩm vì không có title.');
        return;
    }
    addScrapedData({ url, title, description, price, thumbnail, images, sku, content, supplier: 'DaisanHouse', url_supplier: 'https://daisanhouse.vn' });
});
