import { createCheerioRouter, sleep } from 'crawlee';
import { createRandomSleep } from '../helpers/crawler-helper.js';
import { formatContent } from '../helpers/content-helper.js';
import { addScrapedData } from '../helpers/data-saver.js';
import he from 'he';

export const config = {
    pageStart: 1,
    pageEnd: 50, // Giới hạn tối đa 50 trang để tránh lặp vô hạn
    delayMin: 500,
    delayMax: 1000,
};

export const router = createCheerioRouter();

// Handler danh mục: enqueue link sản phẩm
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
    const url = request.loadedUrl;
    log.info(`+ Taiceravn Category: ${url}`);

    // Tìm tất cả link chi tiết sản phẩm trong danh mục
    const productItems = [];
    // Các selector phổ biến cho sản phẩm
    const productSelectors = [
        'a.woocommerce-LoopProduct-link',
        'a[href*="/san-pham/"]',
        '.product-small a',
        '.product a',
        'h2 a',
        'h3 a',
    ];
    for (const selector of productSelectors) {
        $(selector).each(function (i, el) {
            const href = $(el).attr('href');
            if (href && href.includes('/san-pham/') && !href.startsWith('#') && !href.startsWith('javascript:')) {
                const fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
                productItems.push({ url: fullUrl });
            }
        });
        if (productItems.length > 0) break;
    }

    log.info(`Tổng cộng tìm thấy ${productItems.length} sản phẩm.`);

    if (productItems.length > 0) {
        for (const item of productItems) {
            await enqueueLinks({
                urls: [item.url],
                label: 'taiceravn-detail',
                strategy: 'same-domain',
                userData: {}
            });
        }
    }

    // Logic phân trang dạng /page/{số}/
    let currentPage = 1;
    let nextPageUrl = '';
    const pageMatch = url.match(/\/page\/(\d+)\/?$/);
    if (pageMatch) {
        currentPage = parseInt(pageMatch[1], 10);
    }
    if (currentPage < config.pageEnd) {
        const nextPage = currentPage + 1;
        if (url.includes('/page/')) {
            nextPageUrl = url.replace(/\/page\/\d+\/?$/, `/page/${nextPage}/`);
        } else {
            const baseUrl = url.endsWith('/') ? url : url + '/';
            nextPageUrl = baseUrl + `page/${nextPage}/`;
        }
        log.info(`Enqueue trang tiếp theo: ${nextPageUrl} (trang ${nextPage}/${config.pageEnd})`);
        await enqueueLinks({ urls: [nextPageUrl] });
    } else {
        log.info(`Đã đạt giới hạn trang tối đa (${config.pageEnd}). Dừng phân trang.`);
    }
});

// Handler chi tiết sản phẩm
router.addHandler('taiceravn-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ Taiceravn Detail: ${url}`);

    // Bỏ qua URL chỉ có /san-pham/ mà không có thêm path
    if (url === 'https://taiceravn.com/san-pham/' || url.endsWith('/san-pham/')) {
        log.info('Bỏ qua URL chỉ có /san-pham/ mà không có thêm path.');
        return;
    }

    try {
        // Title: lấy từ h1.product_title, h1.product-title, h1.entry-title
        let title = $('h1.product_title, h1.product-title, h1.entry-title').first().text().trim();
        if (!title) {
            title = $('h1').first().text().trim();
        }
        if (!title) {
            log.info('Bỏ qua sản phẩm vì không có title.');
            return;
        }
        // Nếu title bắt đầu bằng 'Gạch', chèn thêm 'lát nền' sau từ 'Gạch'
        if (/^Gạch\b/i.test(title)) {
            title = title.replace(/^Gạch(\s*)/i, 'Gạch lát nền$1');
        }

        // Price: lấy từ .price hoặc .woocommerce-Price-amount
        let price = $('.price').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
        if (!price) {
            price = $('.woocommerce-Price-amount').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
        }

        // Description: lấy từ meta description hoặc .woocommerce-product-details__short-description
        let description = $('meta[name="description"]').attr('content') || '';
        if (!description) {
            description = $('.woocommerce-product-details__short-description').first().text().trim();
        }
        if (!description) {
            description = $('.product-short-description').first().text().trim();
        }

        // SKU: lấy từ .sku hoặc cuối title hoặc url
        let sku = $('.sku').first().text().trim();
        if (!sku) {
            // Lấy mã cuối cùng trong title (chữ+số)
            const titleMatch = title.match(/([A-Za-z0-9]+)$/);
            if (titleMatch && titleMatch[1]) {
                sku = titleMatch[1];
            }
        }
        if (!sku) {
            // Lấy từ url
            const urlParts = url.split('/');
            sku = urlParts[urlParts.length - 1] || '';
        }

        // Images: chỉ lấy ảnh có chứa sku trong link ảnh (không phân biệt hoa thường) và không lấy ảnh png
        let images = [];
        if (sku) {
            $('img').each(function (i, el) {
                const src = $(el).attr('src');
                if (
                    src &&
                    src.includes('/wp-content/uploads/') &&
                    src.toLowerCase().includes(sku.toLowerCase()) &&
                    !src.toLowerCase().endsWith('.png')
                ) {
                    images.push(src);
                }
            });
        }
        images = Array.from(new Set(images));

        // Content: lấy html của class tab-panels
        let content = $('.tab-panels').html() || '';
        content = he.decode(content);
        // Thay số điện thoại 0903872814 thành 0986258282 trong content
        content = content.replace(/0903872814/g, '0986258282');
        content = formatContent(content, 'taiceravn');

        // Thumbnail: lấy ảnh đầu tiên
        let thumbnail = images.length > 0 ? images[0] : '';

        // Tags: lấy text của tất cả <a> trong .tagged_as
        let tags = [];
        $('.tagged_as a').each(function (i, el) {
            const txt = $(el).text().trim();
            if (txt) tags.push(txt);
        });

        // Categories: lấy text của tất cả <a> trong .posted_in
        let categories = [];
        $('.posted_in a').each(function (i, el) {
            const txt = $(el).text().trim();
            if (txt) categories.push(txt);
        });

        const productData = {
            sku,
            url,
            title,
            description,
            price,
            categories,
            tags,
            thumbnail,
            images,
            content,
            supplier: 'Taiceravn',
            url_supplier: 'https://taiceravn.com'
        };

        pushData(productData);
        addScrapedData(productData);
        log.info(`Đã lấy xong dữ liệu sản phẩm: ${title}`);

    } catch (err) {
        log.error('Error in taiceravn-detail handler:', err.message);
    }

    await sleep(createRandomSleep(config.delayMin, config.delayMax));
}); 