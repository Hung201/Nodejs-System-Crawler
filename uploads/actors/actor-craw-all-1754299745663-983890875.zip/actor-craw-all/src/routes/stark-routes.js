import { createCheerioRouter, sleep } from 'crawlee';
import { createRandomSleep } from '../helpers/crawler-helper.js';
import { formatContent } from '../helpers/content-helper.js';
import he from 'he';
import { addScrapedData } from '../helpers/data-saver.js';

export const config = {
    pageStart: 1,
    pageEnd: 50, // Giới hạn tối đa 50 trang để tránh lặp vô hạn
    delayMin: 500,
    delayMax: 1000,
};

export const router = createCheerioRouter();

// Handler danh mục: enqueue link sản phẩm
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
    const url = request.loadedUrl;
    log.info(`+ Stark Category: ${url}`);

    // Tìm tất cả link chi tiết sản phẩm có dạng pro{number}
    const productItems = [];
    $('a[href*="pro"]').each(function (i, el) {
        const href = $(el).attr('href');
        if (href && /pro\d+\.html$/.test(href)) {
            const fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
            productItems.push({ url: fullUrl });
        }
    });

    log.info(`Tổng cộng tìm thấy ${productItems.length} sản phẩm.`);

    if (productItems.length > 0) {
        for (const item of productItems) {
            await enqueueLinks({
                urls: [item.url],
                label: 'stark-detail',
                strategy: 'same-domain',
                userData: {}
            });
        }
    } else {
        log.info('Không tìm thấy link sản phẩm nào.');
    }
});

// Handler chi tiết sản phẩm
router.addHandler('stark-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ Stark Detail: ${url}`);

    try {
        // Title: lấy từ h2 trong div.col-md-6
        let title = $('div.col-md-6 h2').first().text().trim();
        if (!title) {
            // Fallback: h1
            title = $('h1').first().text().trim();
        }
        if (!title) {
            log.info('Bỏ qua sản phẩm vì không có title.');
            return;
        }

        // Description: lấy <p> ngay sau <p class='price'>, nếu không có thì fallback như cũ
        let description = '';
        const priceP = $('p.price').first();
        if (priceP.length) {
            const descP = priceP.next('p');
            if (descP.length) {
                description = descP.text().trim();
            }
        }
        if (!description) {
            description = $('div.text-warning').first().text().trim();
        }
        if (!description) {
            description = $('div.mt-2').first().text().trim();
        }
        if (!description) {
            description = $('meta[name="description"]').attr('content') || '';
        }

        // Price: lấy text node chứa số tiền (ví dụ 456,000đ) nằm sau <span class='sale-price'> trong <span class='price-primary'>, nếu không có thì fallback như cũ
        let price = '';
        const pricePrimary = $('span.price-primary').first();
        if (pricePrimary.length) {
            // Tìm text node sau sale-price
            const salePrice = pricePrimary.find('span.sale-price').first();
            if (salePrice.length) {
                let found = false;
                pricePrimary.contents().each(function (i, el) {
                    if (el === salePrice[0]) {
                        found = true;
                    } else if (found && el.type === 'text') {
                        const txt = $(el).text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
                        if (txt) price = txt;
                    }
                });
            }
        }
        if (!price) {
            price = $('.price').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
        }

        // SKU: lấy từ div chứa "Mã số:" hoặc từ title hoặc từ url
        let sku = '';
        $('div').each(function (i, el) {
            const txt = $(el).text();
            const match = txt.match(/Mã số\s*:\s*([A-Za-z0-9]+)/i);
            if (match && match[1]) {
                sku = match[1].trim();
                return false;
            }
        });
        if (!sku) {
            // Fallback: lấy từ title (chuỗi cuối cùng dạng chữ+số)
            const titleMatch = title.match(/([A-Za-z0-9]+)$/);
            if (titleMatch && titleMatch[1]) {
                sku = titleMatch[1];
            }
        }
        if (!sku) {
            // Fallback: lấy từ URL
            const urlParts = url.split('-');
            sku = urlParts[urlParts.length - 1].replace(/\.html.*/, '').replace(/^pro/, '');
        }

        // Images: lấy tất cả src của img trong col-md-6, loại bỏ ảnh có src bắt đầu https://stark.com.vn/images/ hoặc https://stark.com.vn/upload/product/subs/thumbs/
        let images = [];
        $('div.col-md-6 img').each(function (i, el) {
            const src = $(el).attr('src');
            if (
                src &&
                !/logo|footer|banner/i.test(src) &&
                !src.startsWith('https://stark.com.vn/images/') &&
                !src.startsWith('https://stark.com.vn/upload/product/subs/thumbs/')
            ) {
                images.push(src);
            }
        });
        images = Array.from(new Set(images));

        // Content: lấy các thẻ <p> dưới <h2 class='title-page text-center'>
        let content = '';
        const infoH2 = $('h2.title-page.text-center').first();
        if (infoH2.length) {
            let htmls = [];
            let el = infoH2.next();
            while (el.length && el.is('p')) {
                htmls.push($.html(el));
                el = el.next();
            }
            content = htmls.join('\n');
        }
        if (!content) {
            // Fallback: lấy html của div.col-md-6
            content = $('div.col-md-6').html() || '';
        }
        content = he.decode(content);
        content = formatContent(content, 'stark');

        // Thumbnail: lấy ảnh đầu tiên
        let thumbnail = images.length > 0 ? images[0] : '';

        // Size: lấy từ div.mt-2, text sau 'Kích thước:'
        let size = '';
        const sizeDiv = $('div.mt-2').first();
        if (sizeDiv.length) {
            const match = sizeDiv.text().match(/Kích thước:\s*([\d xXmm]+)$/i);
            if (match && match[1]) {
                size = match[1].trim();
            }
        }

        const productData = {
            sku,
            url,
            title,
            description,
            size,
            price,
            categories: [],
            tags: [],
            thumbnail,
            images,
            content,
            supplier: 'Stark',
            url_supplier: 'https://stark.com.vn'
        };

        pushData(productData);
        addScrapedData(productData);
        log.info(`Đã lấy xong dữ liệu sản phẩm: ${title}`);

    } catch (err) {
        log.error('Error in stark-detail handler:', err.message);
    }

    await sleep(createRandomSleep(config.delayMin, config.delayMax));
}); 