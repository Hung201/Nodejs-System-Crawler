import { createCheerioRouter, sleep } from 'crawlee';
import { createRandomSleep } from '../helpers/crawler-helper.js';
import { formatContent } from '../helpers/content-helper.js';
import he from 'he';
import { addScrapedData } from '../helpers/data-saver.js';

export const config = {
        pageStart: 1,
        pageEnd: 1,
        delayMin: 500,
        delayMax: 1000,
};

export const router = createCheerioRouter();

// Handler danh mục: enqueue link sản phẩm
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
        log.info(`+ TongKhoKeoDan Category: ${request.loadedUrl}`);
        // Tìm tất cả link chi tiết sản phẩm trong danh mục
        const productLinks = new Set();
        $('.products .product-small .box-image a, .products .product .woocommerce-LoopProduct-link, .product-title a, .woocommerce-loop-product__link').each(function (i, el) {
                const href = $(el).attr('href');
                if (href && !href.startsWith('#')) productLinks.add(href.startsWith('http') ? href : new URL(href, request.loadedUrl).href);
        });
        log.info(`Tìm thấy ${productLinks.size} link sản phẩm.`);
        if (productLinks.size > 0) {
                await enqueueLinks({
                        label: 'tongkhokeodan-detail',
                        strategy: 'same-domain',
                        urls: Array.from(productLinks)
                });
                // Phân trang: tự động tăng /page/2, /page/3,...
                const urlObj = new URL(request.loadedUrl);
                let pathname = urlObj.pathname;
                let currentPage = 1;
                // Kiểm tra nếu đã có /page/n trong pathname
                const pageMatch = pathname.match(/\/page\/(\d+)/);
                if (pageMatch) {
                        currentPage = parseInt(pageMatch[1], 10);
                        // Tăng số trang
                        pathname = pathname.replace(/\/page\/(\d+)/, `/page/${currentPage + 1}`);
                } else {
                        // Nếu chưa có, thêm /page/2 vào cuối pathname
                        if (pathname.endsWith('/')) {
                                pathname += 'page/2';
                        } else {
                                pathname += '/page/2';
                        }
                }
                urlObj.pathname = pathname;
                const nextPageUrl = urlObj.toString();
                log.info(`Enqueue page tiếp theo: ${nextPageUrl}`);
                await enqueueLinks({
                        urls: [nextPageUrl]
                        // KHÔNG truyền label ở đây!
                });
        }
});

// Handler chi tiết sản phẩm
router.addHandler('tongkhokeodan-detail', async ({ request, $, log }) => {
        const url = request.loadedUrl;
        log.info(`+ TongKhoKeoDan Detail: ${url}`);
        try {
                // Title: lấy đúng selector h1.product-title hoặc h1.product_title.entry-title
                let title = $('h1.product-title, h1.product_title.entry-title, h1.entry-title, h1').first().text().trim();
                if (!title) {
                        log.info('Bỏ qua sản phẩm vì không có title.');
                        return;
                }
                // Price: lấy đúng selector .woocommerce-Price-amount hoặc .price
                let price = '';
                let priceSale = '';
                // Nếu có class price-on-sale thì lấy giá hiện tại và giá gạch ngang
                const priceOnSale = $('p.price.product-page-price.price-on-sale');
                if (priceOnSale.length) {
                        // Giá hiện tại
                        price = priceOnSale.find('ins .screen-reader-text, ins .woocommerce-Price-amount, ins').last().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
                        // Giá gạch ngang
                        priceSale = priceOnSale.find('del .screen-reader-text, del .woocommerce-Price-amount, del').last().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
                        if (!price) {
                                // Fallback lấy text trong ins
                                price = priceOnSale.find('ins').last().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
                        }
                        if (!priceSale) {
                                // Fallback lấy text trong del
                                priceSale = priceOnSale.find('del').last().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
                        }
                } else {
                        // Nếu không có sale, lấy như cũ
                        price = $('.woocommerce-Price-amount').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
                        if (!price) {
                                price = $('.price, .product-price').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
                        }
                        if (!price) {
                                price = $('body').text().match(/\d+[.,]?\d*/)?.[0] || '';
                        }
                }
                // Description
                let description = $('.product-short-description, .woocommerce-product-details__short-description, .product-desc, .description, .desc').first().text().trim();
                if (!description) {
                        // Lấy đoạn text dài nhất trong các thẻ p
                        let maxLen = 0;
                        $('p').each(function (i, el) {
                                const txt = $(el).text().trim();
                                if (txt.length > maxLen) {
                                        maxLen = txt.length;
                                        description = txt;
                                }
                        });
                }
                // Images
                // Lấy thumbnail là ảnh lớn hiển thị chính (giống ảnh đầu trang chi tiết)
                let thumbnail = '';
                // 1. Ưu tiên lấy href của thẻ <a> đầu tiên trong gallery nếu là ảnh thuộc tongkhokeodan.com
                const aThumb = $('.woocommerce-product-gallery__image a, .product-gallery a').first();
                const aHref = aThumb.attr('href');
                if (aHref && aHref.includes('tongkhokeodan.com')) {
                        thumbnail = aHref;
                }
                // 2. Nếu không có, lấy .woocommerce-product-gallery__image img.wp-post-image
                if (!thumbnail) {
                        thumbnail = $('.woocommerce-product-gallery__image img.wp-post-image').first().attr('src') || '';
                }
                // 3. Nếu không có, lấy img.wp-post-image đầu tiên
                if (!thumbnail) {
                        thumbnail = $('img.wp-post-image').first().attr('src') || '';
                }
                // 4. Nếu vẫn không có, fallback sang img lớn nhất trong gallery
                if (!thumbnail) {
                        let maxW = 0;
                        $('.woocommerce-product-gallery__image img, .product-image img, img').each(function (i, el) {
                                const src = $(el).attr('src');
                                const w = parseInt($(el).attr('width')) || 0;
                                if (src && w > maxW) {
                                        maxW = w;
                                        thumbnail = src;
                                }
                        });
                }
                // Bỏ thumbnail nếu không phải domain tongkhokeodan.com
                if (thumbnail && !thumbnail.includes('tongkhokeodan.com')) {
                        thumbnail = '';
                }
                // Danh sách images: chỉ lấy các ảnh trong gallery, loại bỏ icon/logo/ảnh nhỏ/ảnh rác
                const images = [];
                $('.woocommerce-product-gallery__image a, .product-gallery a').each(function (i, el) {
                        const href = $(el).attr('href');
                        if (
                                href &&
                                href.includes('tongkhokeodan.com') &&
                                !/icon|logo|50x50|100x100|150x150|200x200|policy|ezweb247|facebook|svg|webp/i.test(href)
                        ) {
                                images.push(href);
                        }
                });
                // Nếu không có ảnh nào, fallback sang img trong gallery với điều kiện tương tự
                if (images.length === 0) {
                        $('.woocommerce-product-gallery__image img, .product-gallery img').each(function (i, el) {
                                const src = $(el).attr('src');
                                if (
                                        src &&
                                        src.includes('tongkhokeodan.com') &&
                                        !/icon|logo|50x50|100x100|150x150|200x200|policy|ezweb247|facebook|svg|webp/i.test(src)
                                ) {
                                        images.push(src);
                                }
                        });
                }
                // Lấy categories: chỉ lấy rel='tag' trong span.posted_in chứa 'Categories'
                let categories = [];
                $('span.posted_in').each(function (i, el) {
                        const spanText = $(el).text();
                        if (/Categories/i.test(spanText)) {
                                $(el).find('a[rel="tag"]').each(function (j, a) {
                                        const txt = $(a).text().trim();
                                        if (txt) categories.push(txt);
                                });
                        }
                });
                // Lấy trademark (thương hiệu) chỉ lấy từ span.variable-item-span.variable-item-span-button
                let trademark = $('span.variable-item-span.variable-item-span-button').first().text().trim();
                // Lấy color (màu sắc) - lấy tất cả giá trị title của các li.variable-item.color-variable-item hoặc span.variable-item-span.variable-item-color
                let color = [];
                // 1. Lấy từ li.variable-item.color-variable-item[title]
                $('li.variable-item.color-variable-item[title]').each(function (i, el) {
                        const t = $(el).attr('title');
                        if (t) color.push(t.trim());
                });
                // 2. Nếu không có, lấy từ span.variable-item-span.variable-item-color[title]
                if (color.length === 0) {
                        $('span.variable-item-span.variable-item-color[title]').each(function (i, el) {
                                const t = $(el).attr('title');
                                if (t) color.push(t.trim());
                        });
                }
                // 3. Nếu vẫn không có, fallback lấy text
                if (color.length === 0) {
                        $('span.variable-item-span.variable-item-color').each(function (i, el) {
                                const txt = $(el).text().trim();
                                if (txt) color.push(txt);
                        });
                }
                // Lấy specifications: chỉ lấy text của span.variable-item-span.variable-item-span-button trong ul[aria-label*='Quy cách']
                let specifications = [];
                // Ưu tiên lấy đúng quy cách
                const quyCachUl = $("ul[aria-label*='Quy cách'], ul[aria-label*='quy cách'], ul[aria-label*='quy-cach']");
                if (quyCachUl.length > 0) {
                        quyCachUl.find('span.variable-item-span.variable-item-span-button').each(function (i, el) {
                                const txt = $(el).text().trim();
                                if (txt) specifications.push(txt);
                        });
                }
                // Nếu không có, fallback lấy span.variable-item-span.variable-item-span-button có data-attribute_name*='quy-cach'
                if (specifications.length === 0) {
                        $("span.variable-item-span.variable-item-span-button[data-attribute_name*='quy-cach']").each(function (i, el) {
                                const txt = $(el).text().trim();
                                if (txt) specifications.push(txt);
                        });
                }
                // Nếu vẫn không có, fallback lấy span.variable-item-span.variable-item-span-button cuối cùng
                if (specifications.length === 0) {
                        const lastSpec = $('span.variable-item-span.variable-item-span-button').last().text().trim();
                        if (lastSpec) specifications.push(lastSpec);
                }
                // Lấy tags: chỉ lấy rel='tag' trong span.tagged_as chứa 'Tags'
                let tags = [];
                $('span.tagged_as').each(function (i, el) {
                        const spanText = $(el).text();
                        if (/Tags/i.test(spanText)) {
                                $(el).find('a[rel="tag"]').each(function (j, a) {
                                        const txt = $(a).text().trim();
                                        if (txt) tags.push(txt);
                                });
                        }
                });
                // Lấy content: ưu tiên id=accordion-description-content, class=accordion-inner
                let content = $('#accordion-description-content.accordion-inner').html() ||
                        $('.accordion-description-content.accordion-inner').html() ||
                        $('.woocommerce-Tabs-panel--description, .product-content, .entry-content, .product-details, .product-short-description').first().html() || '';
                content = he.decode(content);
                content = formatContent(content, 'tongkhokeodan');
                // Lấy sku: lấy id từ div có class dạng 'post-xxxx' (ví dụ: post-7892)
                let sku = '';
                const productDiv = $("div[class*='post-']").filter(function () {
                        const cls = $(this).attr('class') || '';
                        return /post-\d+/.test(cls);
                }).first();
                if (productDiv.length) {
                        const cls = productDiv.attr('class');
                        const match = cls.match(/post-(\d+)/);
                        if (match) sku = `TKKD-${match[1]}`;
                }
                const productData = {
                        url,
                        sku,
                        title,
                        price,
                        price_original: priceSale,
                        thumbnail,
                        images,
                        description,
                        categories,
                        supplier: 'tongkhokeodan',
                        url_supplier: 'https://tongkhokeodan.com/',
                        trademark,
                        color,
                        specifications,
                        tags,
                        content
                };
                addScrapedData(productData);
                log.info('Đã lấy xong dữ liệu sản phẩm tongkhokeodan!');
        } catch (err) {
                log.error('Error in tongkhokeodan-detail handler:', err.message);
        }
        await sleep(createRandomSleep(config.delayMin, config.delayMax));
}); 