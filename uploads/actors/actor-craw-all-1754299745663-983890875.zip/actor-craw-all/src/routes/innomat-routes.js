import { createCheerioRouter, sleep } from 'crawlee';
import { formatContent } from '../helpers/content-helper.js';
import { addScrapedData } from '../helpers/data-saver.js';
import he from 'he';

export const config = {
    pageStart: 1,
    pageEnd: 50, // Giới hạn tối đa 50 trang để tránh lặp vô hạn
    delayMin: 300,
    delayMax: 800,
};

export const router = createCheerioRouter();

// Handler danh mục: lấy tất cả link sản phẩm, phân trang
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
    const url = request.loadedUrl;
    log.info(`+ Innomat Category: ${url}`);
    const productLinks = new Set();
    // Lấy tất cả link sản phẩm có dạng https://innomat.vn/ten-san-pham
    $('a').each(function (i, el) {
        const href = $(el).attr('href');
        if (href && /^https:\/\/innomat.vn\/[a-zA-Z0-9\-_/]+\/?$/.test(href) && !href.includes('/page/')) {
            productLinks.add(href);
        }
    });
    log.info(`Tìm thấy ${productLinks.size} link sản phẩm.`);
    if (productLinks.size > 0) {
        await enqueueLinks({
            label: 'innomat-detail',
            strategy: 'same-domain',
            urls: Array.from(productLinks)
        });
    }
    // Phân trang: tự động tăng /page/2, /page/3,...
    const pageMatch = url.match(/\/page\/(\d+)/);
    let currentPage = pageMatch ? parseInt(pageMatch[1], 10) : 1;
    if (currentPage < config.pageEnd) {
        // Tìm nút phân trang hoặc tự tăng số trang
        const nextPage = currentPage + 1;
        let nextPageUrl = '';
        if (url.includes('/page/')) {
            nextPageUrl = url.replace(/\/page\/(\d+)/, `/page/${nextPage}`);
        } else {
            nextPageUrl = url.endsWith('/') ? url + `page/${nextPage}/` : url + `/page/${nextPage}/`;
        }
        log.info(`Enqueue trang tiếp theo: ${nextPageUrl}`);
        await enqueueLinks({ urls: [nextPageUrl] });
    }
});

// Handler chi tiết sản phẩm
router.addHandler('innomat-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ Innomat Detail: ${url}`);
    // Lấy title
    const title = $('h1.product_title, h1.entry-title, h1').first().text().trim();
    if (!title) {
        log.info('Bỏ qua sản phẩm vì không có title.');
        return;
    }
    // Lấy sku từ title (mã cuối cùng trong title, ví dụ INDC267)
    let sku = '';
    const skuMatch = title.match(/([A-Z0-9\-]+)$/i);
    if (skuMatch) sku = 'INNO-' + skuMatch[1];
    // Lấy thumbnail và images
    let images = [];
    let thumbnail = '';
    // Lấy ảnh đầu tiên trong gallery
    const mainImg = $('.woocommerce-product-gallery__image img, .zoomImg, .woocommerce-product-gallery img').first();
    if (mainImg.length) {
        thumbnail = mainImg.attr('src') || '';
    }
    // Nếu không có thumbnail thì bỏ qua sản phẩm
    if (!thumbnail) {
        log.info('Bỏ qua sản phẩm vì không có thumbnail.');
        return;
    }
    // Lấy tất cả ảnh gallery
    $('.woocommerce-product-gallery__image img, .zoomImg, .woocommerce-product-gallery img').each(function (i, el) {
        const src = $(el).attr('src');
        if (src && !images.includes(src)) images.push(src);
    });
    // Lấy content mô tả
    let content = $('.elementor-element.elementor-element-71b81d6.e-con-full.e-flex.e-con.e-child').first().html() || '';
    content = he.decode(content);
    content = formatContent(content, 'innomat');
    // Lấy giá nếu có
    let price = $('.price, .woocommerce-Price-amount').first().text().trim();
    // Push data
    const productData = {
        url,
        title,
        sku,
        price,
        thumbnail,
        images,
        content,
        supplier: 'Innomat',
        url_supplier: 'https://innomat.vn/'
    };
    pushData(productData);
    addScrapedData(productData);
    log.info(`Đã lấy xong dữ liệu sản phẩm: ${title}`);
    await sleep(Math.floor(Math.random() * (config.delayMax - config.delayMin + 1)) + config.delayMin);
}); 