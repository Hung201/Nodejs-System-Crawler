import { createCheerioRouter } from 'crawlee';
import { addScrapedData } from '../helpers/data-saver.js';
import { formatContent } from '../helpers/content-helper.js';
import fetch from 'node-fetch';
import cheerio from 'cheerio';

export let config = {
    pageStart: 1,
    pageEnd: 50,
};

export let router = createCheerioRouter();

// Handler danh mục: lấy tất cả link sản phẩm từ thẻ a (user truyền url danh mục và các class qua userData)
router.addDefaultHandler(async ({ request, enqueueLinks, $, log, crawler }) => {
    let url = request.loadedUrl;
    let { productLinkSelector, productLinkPattern, maxPages = 10, paginationPattern, apiConfig } = request.userData || {};
    log.info(`+ Unknown Category: ${url}`);

    let productLinks = new Set();

    // Danh sách từ khóa loại trừ mở rộng
    let excludePatterns = [
        '/home', '/pay', '/thanhtoan', '/checkout', '/cart', '/login', '/register',
        '/gio-hang', '/dang-nhap', '/dang-ky', '/lien-he', '/contact', '/tin-tuc', '/news',
        '/about', '/about-us', '/chinh-sach', '/policy', '/dieu-khoan', '/terms',
        '/search', '/tim-kiem', '/filter', '/loc', '/sort', '/sap-xep',
        '/tag', '/category', '/danh-muc', '/brand', '/thuong-hieu',
        '/#', '/javascript:', '/mailto:', '/tel:'
    ];

    // Logic cào link sản phẩm qua API nội bộ (nếu có)
    if (apiConfig && apiConfig.baseUrl) {
        log.info(`Sử dụng API nội bộ: ${apiConfig.baseUrl}`);

        // Lấy tham số cần thiết từ trang (nếu có)
        let apiParams = {};
        if (apiConfig.paramSelectors) {
            for (let [paramName, selector] of Object.entries(apiConfig.paramSelectors)) {
                let value = '';

                // Kiểm tra xem có phải regex pattern không
                if (selector.startsWith('regex:')) {
                    const regexPattern = selector.substring(6); // Bỏ 'regex:' prefix
                    const match = url.match(new RegExp(regexPattern));
                    if (match) {
                        value = match[1] || match[0]; // Lấy group đầu tiên hoặc toàn bộ match
                    }
                } else {
                    // Selector thông thường
                    value = $(selector).attr('value') || $(selector).text().trim();
                }

                if (value) {
                    apiParams[paramName] = value;
                    log.info(`Lấy được ${paramName}: ${value}`);
                }
            }
        }

        // Gọi API để lấy link sản phẩm
        let page = 1;
        let allLinks = new Set();

        while (page <= (apiConfig.maxPages || maxPages)) {
            try {
                // Tạo URL API với tham số
                let apiUrl = apiConfig.baseUrl;
                let requestOptions = {
                    headers: apiConfig.headers || {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Accept-Encoding': 'gzip, deflate',
                        'Connection': 'keep-alive',
                    }
                };

                // Xử lý tham số cho API
                if (apiConfig.method === 'POST') {
                    // POST method với form data
                    const formData = new URLSearchParams();

                    // Thêm tham số cố định
                    if (apiConfig.fixedParams) {
                        for (let [key, value] of Object.entries(apiConfig.fixedParams)) {
                            formData.append(key, value);
                        }
                    }

                    // Thêm tham số động từ trang
                    for (let [paramName, selector] of Object.entries(apiParams)) {
                        formData.append(paramName, selector);
                    }

                    // Thêm số trang 
                    formData.append(apiConfig.pageParam || 'page', page.toString());

                    requestOptions.method = 'POST';
                    requestOptions.body = formData.toString();

                    // Thêm Referer header cho POST request
                    if (!requestOptions.headers['Referer']) {
                        requestOptions.headers['Referer'] = url;
                    }

                } else {
                    // GET method với query parameters
                    const params = new URLSearchParams();

                    // Thêm tham số cố định
                    if (apiConfig.fixedParams) {
                        for (let [key, value] of Object.entries(apiConfig.fixedParams)) {
                            params.append(key, value);
                        }
                    }

                    // Thêm tham số động từ trang
                    for (let [key, value] of Object.entries(apiParams)) {
                        params.append(key, value);
                    }

                    // Thêm số trang
                    params.append(apiConfig.pageParam || 'page', page.toString());

                    apiUrl += (apiUrl.includes('?') ? '&' : '?') + params.toString();
                }

                log.info(`Đang gọi API: ${apiUrl} (${apiConfig.method || 'GET'})`);

                let res = await fetch(apiUrl, requestOptions);

                if (!res.ok) {
                    log.warning(`API trả về lỗi ${res.status} ở page ${page}`);
                    break;
                }

                let html = await res.text();
                if (!html.trim()) {
                    log.info(`API trả về rỗng ở page ${page}, dừng crawl`);
                    break;
                }

                let $$ = cheerio.load(html);
                let found = false;

                // Tìm link sản phẩm trong response API
                let linkSelector = apiConfig.linkSelector || 'a';
                $$(linkSelector).each((i, el) => {
                    let href = $$(el).attr('href');
                    if (!href) return;

                    let fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
                    let lowerUrl = fullUrl.toLowerCase();

                    // Kiểm tra xem có phải link loại trừ không
                    let isExcluded = excludePatterns.some(pattern => lowerUrl.includes(pattern));
                    if (isExcluded) return;

                    // Kiểm tra pattern sản phẩm
                    if (productLinkPattern) {
                        if (lowerUrl.includes(productLinkPattern.toLowerCase())) {
                            allLinks.add(fullUrl);
                            found = true;
                        }
                    } else {
                        // Pattern mặc định cho sản phẩm
                        let productPatterns = ['product', 'san-pham', 'item', 'goods', 'detail'];
                        let isProductLink = productPatterns.some(pattern => lowerUrl.includes(pattern));
                        if (isProductLink) {
                            allLinks.add(fullUrl);
                            found = true;
                        }
                    }
                });

                if (!found) {
                    log.info(`Không tìm thấy link sản phẩm ở page ${page}, dừng crawl`);
                    break;
                }

                page++;

                // Delay giữa các request API
                if (apiConfig.delay) {
                    await new Promise(resolve => setTimeout(resolve, apiConfig.delay));
                }

            } catch (error) {
                log.error(`Lỗi khi gọi API page ${page}:`, error.message);
                break;
            }
        }

        productLinks = allLinks;
        log.info(`API tìm thấy ${productLinks.size} link sản phẩm.`);

    } else if (apiConfig && !apiConfig.baseUrl) {
        log.warning('apiConfig được truyền nhưng thiếu baseUrl, bỏ qua API và sử dụng logic thông thường');
    } else {
        // Logic phân trang: Tạo URL phân trang dựa trên pattern user truyền vào
        if (paginationPattern) {
            log.info(`Tạo URL phân trang với pattern: ${paginationPattern}`);
            let paginationUrls = [];

            for (let page = 2; page <= maxPages; page++) {
                let paginationUrl;

                if (paginationPattern === '?page=') {
                    // Pattern: ?page=2, ?page=3, ...
                    let urlObj = new URL(url);
                    urlObj.searchParams.set('page', page.toString());
                    paginationUrl = urlObj.toString();
                } else if (paginationPattern === '?p=') {
                    // Pattern: ?p=2, ?p=3, ...
                    let urlObj = new URL(url);
                    urlObj.searchParams.set('p', page.toString());
                    paginationUrl = urlObj.toString();
                } else if (paginationPattern === '/page/') {
                    // Pattern: /page/2/, /page/3/, ... (giữ nguyên query params)
                    let urlObj = new URL(url);
                    let pathname = urlObj.pathname.replace(/\/page\/\d+\/?$/, '').replace(/\/$/, '');
                    let search = urlObj.search;
                    paginationUrl = `${urlObj.origin}${pathname}/page/${page}/${search}`;
                } else if (paginationPattern === '/trang/') {
                    // Pattern: /trang/2/, /trang/3/, ... (giữ nguyên query params)
                    let urlObj = new URL(url);
                    let pathname = urlObj.pathname.replace(/\/trang\/\d+\/?$/, '').replace(/\/$/, '');
                    let search = urlObj.search;
                    paginationUrl = `${urlObj.origin}${pathname}/trang/${page}/${search}`;
                } else if (paginationPattern === '&page=') {
                    // Pattern: &page=2, &page=3, ... (cho URL có sẵn params)
                    let separator = url.includes('?') ? '&' : '?';
                    paginationUrl = `${url}${separator}page=${page}`;
                } else if (paginationPattern === '&p=') {
                    // Pattern: &p=2, &p=3, ... (cho URL có sẵn params)
                    let separator = url.includes('?') ? '&' : '?';
                    paginationUrl = `${url}${separator}p=${page}`;
                } else {
                    // Pattern tùy chỉnh: thay {page} bằng số trang
                    paginationUrl = url.replace(/\{page\}/g, page.toString());
                }

                paginationUrls.push(paginationUrl);
            }

            if (paginationUrls.length > 0) {
                log.info(`Tạo ${paginationUrls.length} URL phân trang`);
                await enqueueLinks({
                    label: 'unknown-category',
                    strategy: 'same-domain',
                    urls: paginationUrls,
                    userData: request.userData
                });
            }
        }

        // Nếu user cung cấp selector cụ thể cho link sản phẩm
        if (productLinkSelector) {
            log.info(`Sử dụng selector tùy chỉnh: ${productLinkSelector}`);
            $(productLinkSelector).each(function (i, el) {
                let href = $(el).attr('href');
                if (!href || href.startsWith('#') || href.startsWith('javascript:') || href === '/') return;

                let fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
                productLinks.add(fullUrl);
            });
        } else {
            // Logic thông minh để tìm link sản phẩm
            log.info('Tự động tìm link sản phẩm...');

            // 1. Tìm các link có pattern sản phẩm phổ biến
            let productPatterns = [
                'product', 'san-pham', 'item', 'goods', 'detail',
                'p/', 'sp/', 'prd/', 'pid=', 'product_id='
            ];

            $('a').each(function (i, el) {
                let href = $(el).attr('href');
                if (!href || href.startsWith('#') || href.startsWith('javascript:') || href === '/') return;

                let fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
                let lowerUrl = fullUrl.toLowerCase();

                // Kiểm tra xem có phải link loại trừ không
                let isExcluded = excludePatterns.some(pattern => lowerUrl.includes(pattern));
                if (isExcluded) return;

                // Nếu user cung cấp pattern cụ thể, ưu tiên kiểm tra pattern này
                if (productLinkPattern) {
                    if (lowerUrl.includes(productLinkPattern.toLowerCase())) {
                        productLinks.add(fullUrl);
                    }
                    return; // Chỉ lấy link khớp pattern, không lấy link khác
                }

                // Nếu không có pattern cụ thể, kiểm tra xem có phải link sản phẩm không
                let isProductLink = productPatterns.some(pattern => lowerUrl.includes(pattern));
                if (isProductLink) {
                    productLinks.add(fullUrl);
                }
            });
        }
    }

    log.info(`Tìm thấy ${productLinks.size} link sản phẩm.`);

    // Giới hạn số lượng link để tránh quá tải
    let maxLinks = 200;
    let limitedLinks = Array.from(productLinks).slice(0, maxLinks);

    if (limitedLinks.length > 0) {
        log.info(`Enqueue ${limitedLinks.length} link sản phẩm (giới hạn ${maxLinks})`);
        await enqueueLinks({
            label: 'unknown-detail',
            strategy: 'same-domain',
            urls: limitedLinks,
            userData: request.userData
        });
    } else {
        log.warning('Không tìm thấy link sản phẩm nào. Có thể cần điều chỉnh selector hoặc pattern.');
    }
});

// Handler cho trang phân trang (sử dụng lại logic tương tự)
router.addHandler('unknown-category', async ({ request, enqueueLinks, $, log, crawler }) => {
    let url = request.loadedUrl;
    let { productLinkSelector, productLinkPattern, maxPages = 10, paginationPattern } = request.userData || {};
    log.info(`+ Unknown Category (Pagination): ${url}`);

    let productLinks = new Set();

    // Danh sách từ khóa loại trừ mở rộng
    let excludePatterns = [
        '/home', '/pay', '/thanhtoan', '/checkout', '/cart', '/login', '/register',
        '/gio-hang', '/dang-nhap', '/dang-ky', '/lien-he', '/contact', '/tin-tuc', '/news',
        '/about', '/about-us', '/chinh-sach', '/policy', '/dieu-khoan', '/terms',
        '/search', '/tim-kiem', '/filter', '/loc', '/sort', '/sap-xep',
        '/tag', '/category', '/danh-muc', '/brand', '/thuong-hieu',
        '/#', '/javascript:', '/mailto:', '/tel:'
    ];

    // Logic phân trang: Tạo URL phân trang dựa trên pattern user truyền vào
    if (paginationPattern) {
        log.info(`Tạo URL phân trang với pattern: ${paginationPattern}`);
        let paginationUrls = [];

        for (let page = 2; page <= maxPages; page++) {
            let paginationUrl;

            if (paginationPattern === '?page=') {
                // Pattern: ?page=2, ?page=3, ...
                let urlObj = new URL(url);
                urlObj.searchParams.set('page', page.toString());
                paginationUrl = urlObj.toString();
            } else if (paginationPattern === '?p=') {
                // Pattern: ?p=2, ?p=3, ...
                let urlObj = new URL(url);
                urlObj.searchParams.set('p', page.toString());
                paginationUrl = urlObj.toString();
            } else if (paginationPattern === '/page/') {
                // Pattern: /page/2/, /page/3/, ...
                let baseUrl = url.replace(/\/page\/\d+\/?$/, '').replace(/\/$/, '');
                paginationUrl = `${baseUrl}/page/${page}/`;
            } else if (paginationPattern === '/trang/') {
                // Pattern: /trang/2/, /trang/3/, ...
                let baseUrl = url.replace(/\/trang\/\d+\/?$/, '').replace(/\/$/, '');
                paginationUrl = `${baseUrl}/trang/${page}/`;
            } else if (paginationPattern === '&page=') {
                // Pattern: &page=2, &page=3, ... (cho URL có sẵn params)
                let separator = url.includes('?') ? '&' : '?';
                paginationUrl = `${url}${separator}page=${page}`;
            } else if (paginationPattern === '&p=') {
                // Pattern: &p=2, &p=3, ... (cho URL có sẵn params)
                let separator = url.includes('?') ? '&' : '?';
                paginationUrl = `${url}${separator}p=${page}`;
            } else {
                // Pattern tùy chỉnh: thay {page} bằng số trang
                paginationUrl = url.replace(/\{page\}/g, page.toString());
            }

            paginationUrls.push(paginationUrl);
        }

        if (paginationUrls.length > 0) {
            log.info(`Tạo ${paginationUrls.length} URL phân trang`);
            await enqueueLinks({
                label: 'unknown-category',
                strategy: 'same-domain',
                urls: paginationUrls,
                userData: request.userData
            });
        }
    }

    // Nếu user cung cấp selector cụ thể cho link sản phẩm
    if (productLinkSelector) {
        log.info(`Sử dụng selector tùy chỉnh: ${productLinkSelector}`);
        $(productLinkSelector).each(function (i, el) {
            let href = $(el).attr('href');
            if (!href || href.startsWith('#') || href.startsWith('javascript:') || href === '/') return;

            let fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
            productLinks.add(fullUrl);
        });
    } else {
        // Logic thông minh để tìm link sản phẩm
        log.info('Tự động tìm link sản phẩm...');

        // 1. Tìm các link có pattern sản phẩm phổ biến
        let productPatterns = [
            'product', 'san-pham', 'item', 'goods', 'detail',
            'p/', 'sp/', 'prd/', 'pid=', 'product_id='
        ];

        $('a').each(function (i, el) {
            let href = $(el).attr('href');
            if (!href || href.startsWith('#') || href.startsWith('javascript:') || href === '/') return;

            let fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
            let lowerUrl = fullUrl.toLowerCase();

            // Kiểm tra xem có phải link loại trừ không
            let isExcluded = excludePatterns.some(pattern => lowerUrl.includes(pattern));
            if (isExcluded) return;

            // Nếu user cung cấp pattern cụ thể, ưu tiên kiểm tra pattern này
            if (productLinkPattern) {
                if (lowerUrl.includes(productLinkPattern.toLowerCase())) {
                    productLinks.add(fullUrl);
                }
                return; // Chỉ lấy link khớp pattern, không lấy link khác
            }

            // Nếu không có pattern cụ thể, kiểm tra xem có phải link sản phẩm không
            let isProductLink = productPatterns.some(pattern => lowerUrl.includes(pattern));
            if (isProductLink) {
                productLinks.add(fullUrl);
            }
        });
    }

    log.info(`Tìm thấy ${productLinks.size} link sản phẩm.`);

    // Giới hạn số lượng link để tránh quá tải
    let maxLinks = 200;
    let limitedLinks = Array.from(productLinks).slice(0, maxLinks);

    if (limitedLinks.length > 0) {
        log.info(`Enqueue ${limitedLinks.length} link sản phẩm (giới hạn ${maxLinks})`);
        await enqueueLinks({
            label: 'unknown-detail',
            strategy: 'same-domain',
            urls: limitedLinks,
            userData: request.userData
        });
    } else {
        log.warning('Không tìm thấy link sản phẩm nào. Có thể cần điều chỉnh selector hoặc pattern.');
    }
});

// Handler chi tiết sản phẩm: lấy dữ liệu theo class do user truyền vào
router.addHandler('unknown-detail', async ({ request, $, log, pushData }) => {
    let url = request.loadedUrl;
    let { titleClass, descriptionClass, priceClass, skuClass, contentClass, thumbnailClass, imagesClass, autoGenerateSku, websiteName, isPrice, supplier, url_supplier } = request.userData || {};
    log.info(`+ Unknown Detail: ${url}`);

    try {
        // Lấy title với multiple selectors
        let title = '';
        if (titleClass) {
            let selectors = titleClass.split(',').map(s => s.trim());
            for (let selector of selectors) {
                let element = $(selector).first();
                if (element.length > 0) {
                    title = element.text().trim();
                    if (title) {
                        log.info(`Tìm thấy title với selector: ${selector}`);
                        break;
                    }
                }
            }
        }

        if (!title) {
            log.warning(`Không tìm thấy title với các selector: ${titleClass}`);
            log.info('Thử tìm title với các selector mặc định...');

            // Thử các selector mặc định
            let defaultSelectors = ['h1', '.product-title', '.title', '.product-detail_title', '.product-name'];
            for (let selector of defaultSelectors) {
                let element = $(selector).first();
                if (element.length > 0) {
                    title = element.text().trim();
                    if (title) {
                        break;
                    }
                }
            }
        }

        if (!title) {
            log.info('Bỏ qua sản phẩm vì không có title.');
            return;
        }

        // Lấy description
        let description = '';
        if (descriptionClass) {
            description = $(descriptionClass).first().text().trim();
        }

        // Lấy price
        let price = priceClass ? $(priceClass).first().text().trim() : '';

        // Lọc chỉ lấy số từ price (loại bỏ đ, dấu phẩy, dấu chấm)
        if (price) {
            // Loại bỏ các ký tự không phải số
            price = price.replace(/[^\d]/g, '');
        }

        // Kiểm tra isPrice: nếu true thì bỏ qua sản phẩm không có giá
        if (isPrice && !price) {
            log.info('Bỏ qua sản phẩm vì không có giá và isPrice = true.');
            return;
        }

        // Lấy sku
        let sku = '';
        if (skuClass) {
            sku = $(skuClass).first().text().trim();
        }

        // Tự động tạo SKU nếu không có và được bật tính năng
        if (!sku && autoGenerateSku) {
            // Lấy domain từ URL
            let domain = new URL(url).hostname.replace('www.', '');
            let websitePrefix = websiteName || domain.split('.')[0].toUpperCase();

            // Tạo hash từ title (chỉ 3 ký tự đầu)
            let titleHash = title.replace(/[^a-zA-Z0-9]/g, '').substring(0, 3).toUpperCase();

            // Tạo số độc nhất từ URL và title
            let uniqueNumber = '';

            // Lấy số từ URL nếu có
            let urlMatch = url.match(/\d+/);
            if (urlMatch) {
                uniqueNumber = urlMatch[0].substring(0, 3); // Lấy 3 số đầu
            }

            // Nếu không có số hoặc số quá ngắn, tạo hash từ URL + title
            if (!uniqueNumber || uniqueNumber.length < 3) {
                // Tạo hash từ URL + title để đảm bảo độc nhất
                let combinedString = url + title;
                let hash = 0;
                for (let i = 0; i < combinedString.length; i++) {
                    let char = combinedString.charCodeAt(i);
                    hash = ((hash << 5) - hash) + char;
                    hash = hash & hash; // Convert to 32bit integer
                }
                uniqueNumber = Math.abs(hash).toString().substring(0, 4);
            }

            // Tạo SKU: WEBSITE_TITLEHASH_NUMBER
            sku = `${websitePrefix}_${titleHash}_${uniqueNumber}`;

            // Giới hạn độ dài SKU (15-20 ký tự)
            if (sku.length > 20) {
                // Cắt bớt title hash nếu quá dài
                let maxTitleLength = 20 - websitePrefix.length - uniqueNumber.length - 2; // -2 cho dấu _
                if (maxTitleLength > 0) {
                    titleHash = titleHash.substring(0, maxTitleLength);
                    sku = `${websitePrefix}_${titleHash}_${uniqueNumber}`;
                } else {
                    // Nếu vẫn quá dài, chỉ dùng prefix + số
                    sku = `${websitePrefix}_${uniqueNumber}`;
                }
            }

            log.info(`Tự động tạo SKU: ${sku}`);
        }

        // Lấy thumbnail
        let thumbnail = '';
        if (thumbnailClass) {
            let thumbnailElement = $(thumbnailClass).first();
            if (thumbnailElement.length > 0) {
                // Lấy src từ img hoặc background-image từ CSS
                thumbnail = thumbnailElement.attr('src') || thumbnailElement.attr('data-src') || '';

                // Nếu không có src, thử lấy từ background-image
                if (!thumbnail) {
                    let style = thumbnailElement.attr('style') || '';
                    let bgMatch = style.match(/background-image:\s*url\(['"]?([^'"]+)['"]?\)/);
                    if (bgMatch) {
                        thumbnail = bgMatch[1];
                    }
                }

                // Chuyển thành URL tuyệt đối nếu cần
                if (thumbnail && !thumbnail.startsWith('http')) {
                    thumbnail = new URL(thumbnail, url).href;
                }
            }
        } else {
            // Fallback: lấy ảnh đầu tiên từ trang
            let firstImg = $('img').first();
            if (firstImg.length > 0) {
                thumbnail = firstImg.attr('src') || '';
                if (thumbnail && !thumbnail.startsWith('http')) {
                    thumbnail = new URL(thumbnail, url).href;
                }
                log.info(`Sử dụng ảnh đầu tiên làm thumbnail: ${thumbnail}`);
            }
        }

        // Lấy tất cả ảnh sản phẩm
        let images = [];
        if (imagesClass) {
            $(imagesClass).each(function (i, el) {
                let imgSrc = $(el).attr('src') || $(el).attr('data-src') || '';

                // Nếu không có src, thử lấy từ background-image
                if (!imgSrc) {
                    let style = $(el).attr('style') || '';
                    let bgMatch = style.match(/background-image:\s*url\(['"]?([^'"]+)['"]?\)/);
                    if (bgMatch) {
                        imgSrc = bgMatch[1];
                    }
                }

                // Chuyển thành URL tuyệt đối nếu cần
                if (imgSrc && !imgSrc.startsWith('http')) {
                    imgSrc = new URL(imgSrc, url).href;
                }

                // Lọc ảnh theo pattern nếu có
                if (imgSrc && !images.includes(imgSrc)) {
                    let shouldInclude = true;

                    // Kiểm tra imageFilters nếu có
                    if (request.userData.imageFilters) {
                        const { includePatterns = [], excludePatterns = [], skuInImage } = request.userData.imageFilters;

                        // Kiểm tra exclude patterns trước
                        for (let pattern of excludePatterns) {
                            if (imgSrc.toLowerCase().includes(pattern.toLowerCase())) {
                                shouldInclude = false;
                                log.info(`Loại bỏ ảnh vì khớp exclude pattern: ${pattern}`);
                                break;
                            }
                        }

                        // Nếu không bị loại bỏ, kiểm tra include patterns
                        if (shouldInclude && includePatterns.length > 0) {
                            shouldInclude = false;
                            for (let pattern of includePatterns) {
                                if (imgSrc.toLowerCase().includes(pattern.toLowerCase())) {
                                    shouldInclude = true;
                                    break;
                                }
                            }
                            if (!shouldInclude) {
                                log.info(`Loại bỏ ảnh vì không khớp include pattern nào`);
                            }
                        }

                        // Kiểm tra SKU trong ảnh nếu có yêu cầu
                        if (shouldInclude && skuInImage && sku) {
                            // Tìm SKU trong URL ảnh (không phân biệt hoa thường)
                            let skuFound = false;
                            let skuPatterns = [
                                sku.toLowerCase(),
                                sku.toUpperCase(),
                                sku.replace(/[^a-zA-Z0-9]/g, '').toLowerCase(),
                                sku.replace(/[^a-zA-Z0-9]/g, '').toUpperCase(),
                                sku.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase(),
                                sku.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()
                            ];

                            for (let pattern of skuPatterns) {
                                if (imgSrc.toLowerCase().includes(pattern.toLowerCase())) {
                                    skuFound = true;
                                    log.info(`Tìm thấy SKU ${sku} trong ảnh: ${imgSrc}`);
                                    break;
                                }
                            }

                            if (!skuFound) {
                                shouldInclude = false;
                                log.info(`Loại bỏ ảnh vì không chứa SKU ${sku}`);
                            }
                        }
                    }

                    if (shouldInclude) {
                        if (!imgSrc.startsWith('http')) {
                            imgSrc = new URL(imgSrc, url).href;
                        }
                        images.push(imgSrc);
                    }
                }
            });

            log.info(`Tìm thấy ${images.length} ảnh sản phẩm (fallback)`);
        } else {
            // Fallback: lấy tất cả ảnh từ trang (loại bỏ ảnh không phải sản phẩm)
            $('img').each(function (i, el) {
                let imgSrc = $(el).attr('src') || '';

                // Loại bỏ ảnh không phải sản phẩm
                if (imgSrc &&
                    !imgSrc.includes('logo') &&
                    !imgSrc.includes('icon') &&
                    !imgSrc.includes('banner') &&
                    !imgSrc.includes('ads') &&
                    !imgSrc.includes('thumb') &&
                    imgSrc.includes('upload') && // Chỉ lấy ảnh upload
                    !images.includes(imgSrc)) {

                    // Lọc ảnh theo pattern nếu có
                    let shouldInclude = true;

                    // Kiểm tra imageFilters nếu có
                    if (request.userData.imageFilters) {
                        const { includePatterns = [], excludePatterns = [], skuInImage } = request.userData.imageFilters;

                        // Kiểm tra exclude patterns trước
                        for (let pattern of excludePatterns) {
                            if (imgSrc.toLowerCase().includes(pattern.toLowerCase())) {
                                shouldInclude = false;
                                log.info(`Loại bỏ ảnh vì khớp exclude pattern: ${pattern}`);
                                break;
                            }
                        }

                        // Nếu không bị loại bỏ, kiểm tra include patterns
                        if (shouldInclude && includePatterns.length > 0) {
                            shouldInclude = false;
                            for (let pattern of includePatterns) {
                                if (imgSrc.toLowerCase().includes(pattern.toLowerCase())) {
                                    shouldInclude = true;
                                    break;
                                }
                            }
                            if (!shouldInclude) {
                                log.info(`Loại bỏ ảnh vì không khớp include pattern nào`);
                            }
                        }

                        // Kiểm tra SKU trong ảnh nếu có yêu cầu
                        if (shouldInclude && skuInImage && sku) {
                            // Tìm SKU trong URL ảnh (không phân biệt hoa thường)
                            let skuFound = false;
                            let skuPatterns = [
                                sku.toLowerCase(),
                                sku.toUpperCase(),
                                sku.replace(/[^a-zA-Z0-9]/g, '').toLowerCase(),
                                sku.replace(/[^a-zA-Z0-9]/g, '').toUpperCase(),
                                sku.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase(),
                                sku.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()
                            ];

                            for (let pattern of skuPatterns) {
                                if (imgSrc.toLowerCase().includes(pattern.toLowerCase())) {
                                    skuFound = true;
                                    log.info(`Tìm thấy SKU ${sku} trong ảnh: ${imgSrc}`);
                                    break;
                                }
                            }

                            if (!skuFound) {
                                shouldInclude = false;
                                log.info(`Loại bỏ ảnh vì không chứa SKU ${sku}`);
                            }
                        }
                    }

                    if (shouldInclude) {
                        if (!imgSrc.startsWith('http')) {
                            imgSrc = new URL(imgSrc, url).href;
                        }
                        images.push(imgSrc);
                    }
                }
            });

            log.info(`Tìm thấy ${images.length} ảnh sản phẩm (fallback)`);
        }

        // Lấy content (html)
        let content = contentClass ? $(contentClass).first().html() || '' : '';

        // Format content với style unknown
        if (content) {
            content = formatContent(content, 'unknown');
        }

        // Push data
        let productData = {
            url,
            title,
            description,
            price,
            sku,
            thumbnail,
            images,
            content,
            supplier: supplier || '',
            url_supplier: url_supplier || ''
        };

        pushData(productData);
        addScrapedData(productData);
        log.info(`Đã lấy xong dữ liệu sản phẩm: ${title}`);
    } catch (err) {
        log.error('Error in unknown-detail handler:', err.message);
    }
});

// Ví dụ input.json tối ưu:
// {
//         "startUrls": [
//                 {
//                         "url": "https://example.com/category",
//                         "userData": {
//                                 "productLinkSelector": ".product-item a", // Selector cụ thể cho link sản phẩm
//                                 "productLinkPattern": "product", // Hoặc pattern để nhận diện link sản phẩm
//                                 "titleClass": ".product-title",
//                                 "descriptionClass": ".product-description",
//                                 "priceClass": ".product-price",
//                                 "skuClass": ".product-sku",
//                                 "contentClass": ".product-content"
//                         }
//                 }
//         ]
// }