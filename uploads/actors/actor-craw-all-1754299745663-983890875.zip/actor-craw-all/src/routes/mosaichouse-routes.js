import { createCheerioRouter } from 'crawlee';
import { formatContent } from '../helpers/content-helper.js';
import he from 'he';

export const config = {};
export const router = createCheerioRouter();

// Biến toàn cục lưu link sản phẩm khi phân trang
const productLinks = new Set();
const MAX_PAGE = 8; // Tùy chỉnh số trang tối đa nếu cần

// Handler danh mục: thu thập tất cả link sản phẩm qua các trang, sau đó enqueue chi tiết
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
    log.info(`+ Mosaichouse Category: ${request.loadedUrl}`);
    // Quét link sản phẩm và thumbnail trên trang hiện tại
    $('.product-thumb').each(function (i, el) {
        const aTag = $(el).find('.image a[href$=".html"]');
        const href = aTag.attr('href');
        let img = aTag.find('img').attr('src');
        if (!img) {
            // Nếu img không nằm trong a, lấy img đầu tiên trong .image
            img = $(el).find('.image img').attr('src');
        }
        if (href) {
            const fullUrl = href.startsWith('http') ? href : new URL(href, request.loadedUrl).href;
            let thumbnail = img || '';
            if (thumbnail && thumbnail.startsWith('/')) {
                thumbnail = 'https://www.mosaichouse.vn' + thumbnail;
            }
            productLinks.add(JSON.stringify({ url: fullUrl, thumbnail }));
        }
    });
    // Phân trang: tự động tăng ?page={int} từ 1 đến 8
    const urlObj = new URL(request.loadedUrl);
    const currentPage = Number(urlObj.searchParams.get('page') || 1);
    const hasProduct = $('.product-thumb .image a[href$=".html"]').length > 0;
    if (hasProduct && currentPage < MAX_PAGE) {
        const nextPage = currentPage + 1;
        urlObj.searchParams.set('page', nextPage);
        const nextPageUrl = urlObj.toString();
        log.info(`Enqueue page tiếp theo: ${nextPageUrl}`);
        await enqueueLinks({ urls: [nextPageUrl] });
    } else {
        log.info(`Đã thu thập đủ link sản phẩm (${productLinks.size}), bắt đầu enqueue chi tiết.`);
        const detailLinks = Array.from(productLinks).map(str => JSON.parse(str));
        for (const item of detailLinks) {
            await enqueueLinks({
                urls: [item.url],
                label: 'mosaichouse-detail',
                strategy: 'same-domain',
                userData: { thumbnail: item.thumbnail }
            });
        }
        productLinks.clear();
    }
});

// Handler chi tiết sản phẩm: lấy thumbnail từ userData nếu có
router.addHandler('mosaichouse-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ Mosaichouse Detail: ${url}`);
    // Lấy title sản phẩm
    const title = $('div.pro-desc h2').first().text().trim();
    // Lấy price sản phẩm, chỉ lấy số, bỏ chữ VNĐ
    let price = $('span.regular-price.span_red').first().text().trim();
    price = price.replace(/[^\d.]/g, '');
    // Lấy images: chỉ lấy các url ảnh có chứa phần số của sku trong tên file
    const images = [];
    let sku_temp = '';
    const skuMatch = (title || '').match(/([A-Z]{2,}\s?(\d{3,}))/i);
    let skuNumber = '';
    if (skuMatch) {
        sku_temp = skuMatch[1]; // sku_temp giữ nguyên, có thể có dấu cách
        skuNumber = skuMatch[2];
    }
    if (skuNumber) {
        $('img').each(function (i, el) {
            let src = $(el).attr('src');
            if (src && src.includes('/image/cache/catalog/san_pham/')) {
                if (src.startsWith('/')) {
                    src = 'https://www.mosaichouse.vn' + src;
                }
                // Chỉ lấy ảnh nếu src chứa phần số của sku
                if (src.includes(skuNumber)) {
                    if (!images.includes(src)) images.push(src);
                }
            }
        });
    }
    // Lấy thumbnail từ userData nếu có, nếu không thì lấy ảnh đầu tiên trong images
    let thumbnail = request.userData && request.userData.thumbnail ? request.userData.thumbnail : (images.length > 0 ? images[0] : '');
    // Lấy sku từ thumbnail hoặc images: tìm đoạn có dạng MH xxxx, TC xxxxx, v.v.
    let sku = '';
    const skuMatchFromThumbnail = (thumbnail + ' ' + images.join(' ')).match(/([A-Z]{2,}\s?\d{3,})/i);
    if (skuMatchFromThumbnail) {
        sku = skuMatchFromThumbnail[1].replace(/\s+/g, ''); // sku trả về là không có dấu cách
    } else {
        // Fallback: lấy từ title nếu có
        const titleMatch = title.match(/([A-Z]{2,}\s?\d{3,})/i);
        if (titleMatch) sku = titleMatch[1].replace(/\s+/g, '');
    }
    // Lấy material: giá trị sau 'Chất Liệu :' trong phần mô tả chi tiết
    let material = '';
    // Tìm trong ul.list-unstyled.des2 hoặc li chứa 'Chất Liệu'
    const materialLi = $('ul.list-unstyled.des2 li').text() || $('li').text();
    const materialMatch = materialLi.match(/Chất Liệu\s*:\s*([^"\n<]*)/i);
    if (materialMatch && materialMatch[1]) {
        material = materialMatch[1].replace(/"/g, '').trim();
    }
    // Lấy color: giá trị sau 'Màu Sắc :' trong phần mô tả chi tiết
    let color = '';
    const colorLi = $('ul.list-unstyled.des2 li').text() || $('li').text();
    const colorMatch = colorLi.match(/Màu Sắc\s*:\s*([^"\n<]*)/i);
    if (colorMatch && colorMatch[1]) {
        color = colorMatch[1].replace(/"/g, '').trim();
    }
    // Lấy content từ .bg-ms-product
    let content = $('.bg-ms-product').html() || '';
    content = he.decode(content);
    content = formatContent(content, 'mosaichouse');
    if (!title) {
        log.info('Bỏ qua sản phẩm vì không có title.');
        return;
    }
    pushData({ url, sku, title, price, color, material, thumbnail, images, content, supplier: 'Mosaichouse', url_supplier: 'https://www.mosaichouse.vn' });
}); 