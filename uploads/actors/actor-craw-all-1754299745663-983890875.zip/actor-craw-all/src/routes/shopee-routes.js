import { createPuppeteerRouter, Dataset } from 'crawlee';

export const config = {};

export const router = createPuppeteerRouter();

// Dán cookie Shopee của bạn vào đây nếu cần đăng nhập để crawl
const SHOPEE_COOKIE = 'gS1oEfmKxkgkkuVta9UkM/QtLrsGHKXD7HzVRf4wACb7gd4+XAnQX2DB5FjeROIyhjigVkDglxgNceFRR+siURNtZu+ImIc3lQVInrqiF4km+is+QwbbgYGjopqwkGt7NyEhQ3Frf4SOq1uKrxC4L6mc+BWHlrhIJej3Xx4k0sD9zsjWiHCzhsYlgDpdh+iR1XPfG0qF5emMu+w5NcHvEJhR3DtEVwLm5RB7Rz9JM6BBszlOUsAcy+yla+sl4xzt8LSOSbFIBCpcd+9nnPaz0ew==_1_1590643745	';

router.addDefaultHandler(async ({ page, request, log }) => {
    log.info(`+ Shopee search: ${request.loadedUrl}`);

    // Set user-agent và header thật giống Chrome
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    await page.setExtraHTTPHeaders({
        'accept-language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
    });

    // Nếu có cookie, set cookie trước khi vào trang
    if (SHOPEE_COOKIE && SHOPEE_COOKIE.trim()) {
        await page.setCookie(
            ...SHOPEE_COOKIE.split(';').map(pair => {
                const [name, ...rest] = pair.trim().split('=');
                return { name, value: rest.join('='), domain: '.shopee.vn' };
            })
        );
    }

    await page.goto(request.loadedUrl, { waitUntil: 'networkidle2', timeout: 60000 });

    await page.waitForSelector('a[data-sqe="link"]', { timeout: 20000 });
    const productLinks = await page.$$eval('a[data-sqe="link"]', links =>
        links
            .map(a => a.href)
            .filter(href => href.startsWith('https://shopee.vn/') && !href.includes('search?'))
    );
    log.info(`Tìm thấy ${productLinks.length} link sản phẩm.`);
    if (productLinks.length > 0) {
        await Dataset.pushData(productLinks.map(link => ({ link })));
    }
});
