import { createCheerioRouter } from 'crawlee';
import { formatContent } from '../helpers/content-helper.js';
import he from 'he';

export const config = {};

export const router = createCheerioRouter();

// Handler danh mục: thu thập tất cả link sản phẩm
router.addDefaultHandler(async ({ request, enqueueLinks, $, log, pushData }) => {
    log.info(`+ Newlando Category: ${request.loadedUrl}`);
    // Tìm tất cả link sản phẩm có đầu /san-pham/ hoặc https://newlando.vn/san-pham/
    const productLinks = new Set();
    $('a').each(function (i, el) {
        const href = $(el).attr('href');
        if (
            href &&
            (href.startsWith('/san-pham/') || href.startsWith('https://newlando.vn/san-pham/'))
        ) {
            const fullUrl = href.startsWith('http') ? href : new URL(href, request.loadedUrl).origin + href;
            productLinks.add(fullUrl);
        }
    });
    log.info(`Tìm thấy ${productLinks.size} link sản phẩm.`);
    if (productLinks.size > 0) {
        await enqueueLinks({
            label: 'newlando-detail',
            strategy: 'same-domain',
            urls: Array.from(productLinks)
        });
    }
});

// Handler chi tiết sản phẩm: lấy title từ h1.sp-title và images
router.addHandler('newlando-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ Newlando Detail: ${url}`);
    const title = $('h1.sp-title').first().text().trim();
    if (!title) {
        log.info('Bỏ qua sản phẩm vì không có title.');
        return;
    }
    // Lấy tất cả ảnh trong .wcgs-thumb.spswiper-slide
    const images = [];
    $('.wcgs-thumb.spswiper-slide img').each(function (i, el) {
        let src = $(el).attr('src') || $(el).attr('data-image');
        if (src && src.startsWith('https://newlando.vn/wp-content/uploads/2025/')) {
            images.push(src);
        }
    });
    const thumbnail = images.length > 0 ? images[0] : '';
    // Lấy giá
    let price = $('.woocommerce-Price-amount.amount bdi').first().clone()
        .children().remove().end().text().trim(); // loại bỏ ký tự đ
    // Lấy sku
    const sku = $('label.sku').first().text().trim();
    // Lấy content với selector rộng hơn
    let content = $('.tab-des-inner').first().html() || '';
    content = he.decode(content);
    content = formatContent(content, 'newlando');
    pushData({ url, sku, title, price, thumbnail, images, supplier: 'Newlando', url_supplier: 'https://newlando.vn', content });
});
