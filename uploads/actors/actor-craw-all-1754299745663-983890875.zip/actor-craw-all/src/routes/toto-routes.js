import { createCheerioRouter, sleep } from 'crawlee';
import { formatContent } from '../helpers/content-helper.js';
import { addScrapedData } from '../helpers/data-saver.js';
import he from 'he';
import fetch from 'node-fetch';
import cheerio from 'cheerio';

export const config = {
    pageStart: 1,
    pageEnd: 20, // Giới hạn tối đa 20 trang để tránh lặp vô hạn
    delayMin: 300,
    delayMax: 800,
};

export const router = createCheerioRouter();

// Handler danh mục: luôn lấy termId động từ input#termId trên trang đầu vào, nếu không có thì dừng
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
    const url = request.loadedUrl;
    log.info(`+ Toto Category: ${url}`);
    // Lấy termId từ input#termId trên trang
    let termId = $('input#termId').attr('value');
    if (!termId) {
        log.warning('Không tìm thấy termId trên trang danh mục, không thể crawl qua API.');
        return;
    }
    log.info('Đang crawl qua API AJAX với termId: ' + termId);
    const baseApi = 'https://vn.toto.com/wp-admin/admin-ajax.php?action=view_more_product';
    let page = 1;
    let allLinks = new Set();
    while (true) {
        const apiUrl = `${baseApi}&page=${page}&termId=${termId}`;
        log.info('Đang gọi API: ' + apiUrl);
        const res = await fetch(apiUrl);
        const html = await res.text();
        if (!html.trim()) break;
        const $$ = cheerio.load(html);
        let found = false;
        $$('a').each((i, el) => {
            const href = $$(el).attr('href');
            if (href && href.startsWith('https://vn.toto.com/')) {
                allLinks.add(href);
                found = true;
            }
        });
        if (!found) break;
        page++;
    }
    log.info(`Tìm thấy ${allLinks.size} link sản phẩm.`);
    if (allLinks.size > 0) {
        await enqueueLinks({
            label: 'toto-detail',
            strategy: 'same-domain',
            urls: Array.from(allLinks),
            userData: { termId }
        });
    }
});

// Handler chi tiết sản phẩm: thêm trường termId vào productData
router.addHandler('toto-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ Toto Detail: ${url}`);
    try {
        // SKU
        let sku = $('#product_sku').first().text().trim();
        if (!sku) {
            sku = title.replace(/\s+/g, '_');
        }
        // title
        let title = $('.view__desc').first().text().trim();
        if (!title) {
            title = $('meta[name="description"]').attr('content') || '';
        }
        let description = '';
        // Nối title với sku
        title = `${title} ${sku}`.trim();

        // Nếu sku chứa 'TOTO_Tiếng_Việt' thì bỏ qua sản phẩm
        if (sku.includes('TOTO_Tiếng_Việt')) {
            log.info('Bỏ qua sản phẩm vì sku chứa TOTO_Tiếng_Việt.');
            return;
        }
        // Images: luôn để rỗng
        let images = [];
        // Thumbnail: lấy ảnh đầu tiên trong .main-img img (ưu tiên), nếu không thì fallback ảnh đầu tiên phù hợp
        let thumbnail = '';
        const mainImg = $('.main-img img').first();
        if (mainImg.length) {
            thumbnail = mainImg.attr('src') || '';
        }
        if (!thumbnail) {
            $('img').each(function (i, el) {
                const src = $(el).attr('src');
                if (src && /\/wp-content\/webp-express\/webp-images\/uploads\//.test(src) && !thumbnail) {
                    thumbnail = src;
                }
            });
        }
        // Content: lấy html của .detail__desc-content, loại bỏ .content-button và thêm style
        let $desc = $('<div>' + $('.detail__desc-content').html() + '</div>');
        $desc.find('.content-button').remove();
        let content = $desc.html() || '';
        // Bọc lại với class và style như yêu cầu
        content = `<div class="detail__desc-content" style="max-height: fit-content;">${content}</div>`;
        content = he.decode(content);
        content = formatContent(content, 'toto');
        // Price: lấy từ .price_load.view__info-price
        let price = $('.price_load.view__info-price').first().text().trim() || '';
        // Push data
        const productData = {
            sku,
            url,
            title,
            description,
            price,
            thumbnail,
            images,
            content,
            supplier: 'TOTO',
            url_supplier: 'https://vn.toto.com/',
            termId: request.userData && request.userData.termId ? request.userData.termId : ''
        };
        pushData(productData);
        addScrapedData(productData);
        log.info(`Đã lấy xong dữ liệu sản phẩm: ${title}`);
    } catch (err) {
        log.error('Error in toto-detail handler:', err.message);
    }
    await sleep(Math.floor(Math.random() * (config.delayMax - config.delayMin + 1)) + config.delayMin);
}); 