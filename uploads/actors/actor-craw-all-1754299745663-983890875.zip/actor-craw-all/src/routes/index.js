import { detectWebsiteType, WEBSITE_TYPES } from '../helpers/website-detector.js';
import { router as alibabaRouter, config as alibabaConfig } from './alibaba-routes.js';
import { router as inaxRouter, config as inaxConfig } from './inax-routes.js';
import { router as unknownRouter, config as unknownConfig } from './unknown-routes.js';
import { router as tongkhokeodanRouter, config as tongkhokeodanConfig } from './tongkhokeodan-routes.js';
import { router as ecobiglaziotileRouter, config as ecobiglaziotileConfig } from './ecobiglaziotile-routes.js';
import { router as daisanstoreRouter, config as daisanstoreConfig } from './daisanhouse-routes.js';
import { router as grandceramicsRouter, config as grandceramicsConfig } from './grandceramics-routes.js';
import { router as mosaichouseRouter, config as mosaichouseConfig } from './mosaichouse-routes.js';
import { router as newlandoRouter, config as newlandoConfig } from './newlando-routes.js';
import { router as tasaceramicRouter, config as tasaceramicConfig } from './tasaceramic-routes.js';
import { router as shopeeRouter, config as shopeeConfig } from './shopee-routes.js';
import { router as hgcstoneRouter, config as hgcstoneConfig } from './hgcstone-routes.js';
import { router as starkRouter, config as starkConfig } from './stark-routes.js';
import { router as taiceravnRouter, config as taiceravnConfig } from './taiceravn-routes.js';
import { router as lecaophattilesRouter, config as lecaophattilesConfig } from './lecaophattiles-routes.js';
import { router as totoRouter, config as totoConfig } from './toto-routes.js';
import { router as innomatRouter, config as innomatConfig } from './innomat-routes.js';
import { router as gcckhRouter, config as gcckhConfig } from './gachcaocapkhanhhuyen-routes.js';

export const getWebsiteTypeFromInput = (input) => {
        if (input.startUrls && Array.isArray(input.startUrls)) {
                return WEBSITE_TYPES.UNKNOWN;
        }
        return detectWebsiteType(input.shopUrl);
};

export const getRouterByWebsiteType = (websiteType) => {
        switch (websiteType) {
                case WEBSITE_TYPES.ALIBABA:
                        return alibabaRouter;
                case WEBSITE_TYPES.INAX:
                        return inaxRouter;
                case WEBSITE_TYPES.TONGKHO_KEODAN:
                        return tongkhokeodanRouter;
                case WEBSITE_TYPES.ECOBIGLAZIOTILE:
                        return ecobiglaziotileRouter;
                case WEBSITE_TYPES.DAISANSTORE:
                        return daisanstoreRouter;
                case WEBSITE_TYPES.GRANDCERAMICS:
                        return grandceramicsRouter;
                case WEBSITE_TYPES.MOSAICHOUSE:
                        return mosaichouseRouter;
                case WEBSITE_TYPES.NEWLANDO:
                        return newlandoRouter;
                case WEBSITE_TYPES.TASACERAMIC:
                        return tasaceramicRouter;
                case WEBSITE_TYPES.SHOPEE:
                        return shopeeRouter;
                case WEBSITE_TYPES.HGCSTONE:
                        return hgcstoneRouter;
                case WEBSITE_TYPES.STARK:
                        return starkRouter;
                case WEBSITE_TYPES.TAICERAVN:
                        return taiceravnRouter;
                case WEBSITE_TYPES.LECAOPHATTILES:
                        return lecaophattilesRouter;
                case WEBSITE_TYPES.TOTO:
                        return totoRouter;
                case WEBSITE_TYPES.INNOMAT:
                        return innomatRouter;
                case WEBSITE_TYPES.GCCKH:
                        return gcckhRouter;
                case WEBSITE_TYPES.UNKNOWN:
                        return unknownRouter;
                default:
                        throw new Error(`Unsupported website type: ${websiteType}`);
        }
};

export const getConfigByWebsiteType = (websiteType) => {
        switch (websiteType) {
                case WEBSITE_TYPES.ALIBABA:
                        return alibabaConfig;
                case WEBSITE_TYPES.INAX:
                        return inaxConfig;
                case WEBSITE_TYPES.TONGKHO_KEODAN:
                        return tongkhokeodanConfig;
                case WEBSITE_TYPES.ECOBIGLAZIOTILE:
                        return ecobiglaziotileConfig;
                case WEBSITE_TYPES.DAISANSTORE:
                        return daisanstoreConfig;
                case WEBSITE_TYPES.GRANDCERAMICS:
                        return grandceramicsConfig;
                case WEBSITE_TYPES.MOSAICHOUSE:
                        return mosaichouseConfig;
                case WEBSITE_TYPES.NEWLANDO:
                        return newlandoConfig;
                case WEBSITE_TYPES.TASACERAMIC:
                        return tasaceramicConfig;
                case WEBSITE_TYPES.SHOPEE:
                        return shopeeConfig;
                case WEBSITE_TYPES.HGCSTONE:
                        return hgcstoneConfig;
                case WEBSITE_TYPES.STARK:
                        return starkConfig;
                case WEBSITE_TYPES.TAICERAVN:
                        return taiceravnConfig;
                case WEBSITE_TYPES.LECAOPHATTILES:
                        return lecaophattilesConfig;
                case WEBSITE_TYPES.TOTO:
                        return totoConfig;
                case WEBSITE_TYPES.INNOMAT:
                        return innomatConfig;
                case WEBSITE_TYPES.GCCKH:
                        return gcckhConfig;
                case WEBSITE_TYPES.UNKNOWN:
                        return unknownConfig;
                default:
                        throw new Error(`Unsupported website type: ${websiteType}`);
        }
}; 