import { createCheerioRouter, sleep } from 'crawlee';
import { createRandomSleep, getBaseUrl } from '../helpers/crawler-helper.js';
import { formatContent } from '../helpers/content-helper.js';
import { addScrapedData } from '../helpers/data-saver.js';

export const config = {
        pageStart: 1,
        pageEnd: 1,
        delayMin: 100,
        delayMax: 300,
};

const state = {
        page: config.pageStart
};

export const router = createCheerioRouter();

// Bước 1: Lấy tất cả link sản phẩm chi tiết từ trang danh mục
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
        const url = request.loadedUrl;
        log.info(`+ Start Inax Category: ${url}`);

        try {
                const baseUrl = getBaseUrl(url);
                const links = [];

                $('a[href*="/vi/products/"]').each((i, el) => {
                        let href = $(el).attr('href');
                        if (href && href.includes('/vi/products/') && !href.includes('?')) {
                                // Lọc đúng link chi tiết sản phẩm: /vi/products/abc/xyz/
                                const match = href.match(/\/vi\/products\/[^\/]+\/[^\/]+\/?$/);
                                if (match) {
                                        if (!href.startsWith('http')) href = baseUrl + href;
                                        links.push(href);
                                }
                        }
                });

                log.info(`Đã tìm thấy ${links.length} link sản phẩm chi tiết.`);

                if (links.length > 0) {
                        await enqueueLinks({
                                label: 'inax-detail',
                                strategy: 'same-domain',
                                urls: links
                        });

                        // Phân trang: tự động tăng /page/2, /page/3,...
                        const urlObj = new URL(request.loadedUrl);
                        let pathname = urlObj.pathname;
                        let currentPage = 1;
                        // Kiểm tra nếu đã có /page/n trong pathname
                        const pageMatch = pathname.match(/\/page\/(\d+)/);
                        if (pageMatch) {
                                currentPage = parseInt(pageMatch[1], 10);
                                // Tăng số trang
                                pathname = pathname.replace(/\/page\/(\d+)/, `/page/${currentPage + 1}`);
                        } else {
                                // Nếu chưa có, thêm /page/2 vào cuối pathname
                                if (pathname.endsWith('/')) {
                                        pathname += 'page/2';
                                } else {
                                        pathname += '/page/2';
                                }
                        }
                        urlObj.pathname = pathname;
                        const nextPageUrl = urlObj.toString();
                        log.info(`Enqueue page tiếp theo: ${nextPageUrl}`);
                        await enqueueLinks({
                                urls: [nextPageUrl]
                                // KHÔNG truyền label ở đây!
                        });
                } else {
                        log.warning('Không tìm thấy sản phẩm nào trên trang danh mục!');
                }
        }
        catch (err) {
                log.error('Error in inax category handler:', err.message);
        }
});

// Bước 2: Crawl từng sản phẩm chi tiết
router.addHandler('inax-detail', async ({ request, $, log, pushData }) => {
        const url = request.loadedUrl;

        // Kiểm tra URL có phải sản phẩm chi tiết không
        if (!url.match(/^https?:\/\/[^\/]+\/vi\/products\/[^\/]+\/[^\/]+\/?$/)) {
                log.info(`Bỏ qua url không phải sản phẩm chi tiết: ${url}`);
                return;
        }

        log.info(`+ Inax Detail: ${url}`);

        try {
                const title = $('.product-name.text-uppercase').text().trim();
                const description = $('.product-desc').text().trim();
                // Cải thiện lấy giá
                let price = $('.product-price').first().text().trim();
                if (!price) {
                        price = $('.product-properties .product-price').first().text().trim();
                }
                if (!price) {
                        // Tìm <p> chứa số và VND
                        $('p').each((i, el) => {
                                const txt = $(el).text();
                                if (/\d+[.,]?\d*\s*VND/.test(txt)) {
                                        price = txt.trim();
                                        return false;
                                }
                        });
                }

                const color_images = [];
                const skus = [];

                $('.col-md-3.col-sm-6').each((i, el) => {
                        // Lấy ảnh màu sắc
                        let imgSrc = $(el).find('img').attr('data-src') || $(el).find('img').attr('src');
                        if (imgSrc && !imgSrc.includes('productholder.gif')) {
                                color_images.push(imgSrc);
                        }

                        // Lấy sku (mã sản phẩm) đúng định dạng
                        let skuText = $(el).find('div').text().trim();
                        let match = skuText.match(/INAX-[\w/-]+/);
                        if (match) {
                                skus.push(match[0]);
                        } else if (skuText) {
                                skus.push('INAX-' + skuText);
                        }
                });

                // Nếu chỉ có 1 sku thì trả về string, còn nhiều thì trả về mảng
                let sku = skus[0] || '';
                // Nếu không tìm thấy sku, lấy mã cuối trong title (ví dụ AC-514VAN) và tạo sku mới
                if (!sku) {
                        const titleMatch = title.match(/([A-Z0-9\-]+)$/i);
                        if (titleMatch && titleMatch[1]) {
                                sku = 'INAX-' + titleMatch[1];
                        }
                }

                // Loại bỏ phần tải xuống 3D MAXFILES khỏi content
                let $spec = $('.details-specs').first().clone();
                $spec.find('.col-sm-4.mb-5.mb-sm-0').remove();
                const content = $spec.html();

                const productData = {
                        sku: sku,
                        url,
                        title,
                        description,
                        price: price,
                        thumbnail: color_images[0] || '',
                        images: color_images,
                        content: formatContent(content || '', 'inax'),
                        supplier: 'INAX',
                        url_supplier: 'https://inax.com.vn/',
                };
                pushData(productData);
                addScrapedData(productData);
                log.info('Đã lấy xong dữ liệu sản phẩm Inax!');
        }
        catch (err) {
                log.error('Error in inax-detail handler:', err.message);
        }

        // Thêm delay ngẫu nhiên giữa các request
        const delay = createRandomSleep(config.delayMin, config.delayMax);
        await sleep(delay);
}); 