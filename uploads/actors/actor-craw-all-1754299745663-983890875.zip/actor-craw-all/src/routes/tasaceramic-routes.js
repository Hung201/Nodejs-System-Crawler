import { createCheerioRouter } from 'crawlee';

export const config = {};

export const router = createCheerioRouter();

// Handler danh mục: thu thập tất cả link sản phẩm
router.addDefaultHandler(async ({ request, enqueueLinks, $, log, pushData }) => {
    log.info(`+ Tasaceramic Category: ${request.loadedUrl}`);
    // Tìm tất cả link sản phẩm có đầu /product/ hoặc https://tasaceramic.vn/product/
    const productLinks = new Set();
    $('a').each(function (i, el) {
        const href = $(el).attr('href');
        if (
            href &&
            (href.startsWith('/product/') || href.startsWith('https://tasaceramic.vn/product/'))
        ) {
            const fullUrl = href.startsWith('http') ? href : new URL(href, request.loadedUrl).origin + href;
            productLinks.add(fullUrl);
        }
    });
    log.info(`Tìm thấy ${productLinks.size} link sản phẩm.`);
    if (productLinks.size > 0) {
        await enqueueLinks({
            label: 'tasaceramic-detail',
            strategy: 'same-domain',
            urls: Array.from(productLinks)
        });
    }
});

// Handler chi tiết sản phẩm: lấy sku từ span.sku
router.addHandler('tasaceramic-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ Tasaceramic Detail: ${url}`);
    // Lấy sku từ span.sku
    const sku = $('span.sku').first().text().trim();
    pushData({ url, sku });
});