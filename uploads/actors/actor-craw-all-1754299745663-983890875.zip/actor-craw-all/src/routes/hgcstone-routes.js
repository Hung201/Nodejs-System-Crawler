import { createCheerioRouter, sleep } from 'crawlee';
import { createRandomSleep } from '../helpers/crawler-helper.js';
import { formatContent } from '../helpers/content-helper.js';
import { addScrapedData } from '../helpers/data-saver.js';
import he from 'he';

export const config = {
    pageStart: 1,
    pageEnd: 50, // Giới hạn tối đa 50 trang để tránh lặp vô hạn
    delayMin: 500,
    delayMax: 1000,
};

export const router = createCheerioRouter();

// Handler danh mục: enqueue link sản phẩm
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
    const url = request.loadedUrl;
    log.info(`+ HGC Stone Category: ${url}`);

    // Tìm tất cả link chi tiết sản phẩm trong danh mục
    const productItems = [];

    // Các selector để tìm block sản phẩm
    const productBlockSelectors = [
        '.product-item',
        '.product',
        '.col',
        '.item',
        '.product-block',
    ];

    let foundBlockSelector = '';
    for (const blockSelector of productBlockSelectors) {
        if ($(blockSelector).length > 0) {
            foundBlockSelector = blockSelector;
            break;
        }
    }

    if (foundBlockSelector) {
        $(foundBlockSelector).each(function (i, el) {
            // Tìm link sản phẩm trong block
            let linkEl = $(el).find('a[href*="/san-pham"]');
            if (!linkEl.length) linkEl = $(el).find('a');
            const href = linkEl.attr('href');
            if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
                const fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
                if (fullUrl.includes('/san-pham')) {
                    // Tìm thumbnail trong block
                    let thumbImg = $(el).find('img');
                    let thumbnail = '';
                    if (thumbImg.length) {
                        thumbnail = thumbImg.first().attr('src') || '';
                    }
                    productItems.push({ url: fullUrl, thumbnail });
                }
            }
        });
    }

    if (productItems.length > 0) {
        log.info(`Tìm thấy ${productItems.length} sản phẩm với block selector: ${foundBlockSelector}`);
    } else {
        // Fallback: logic cũ nếu không tìm thấy block
        const productLinks = new Set();
        const selectors = [
            'a[href*="/san-pham/"]',
            '.product-item a',
            '.product a',
            'h2 a',
            'h3 a',
            'a.product-title',
            'a.product-name'
        ];
        for (const selector of selectors) {
            $(selector).each(function (i, el) {
                const href = $(el).attr('href');
                if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
                    const fullUrl = href.startsWith('http') ? href : new URL(href, url).href;
                    if (fullUrl.includes('/san-pham')) {
                        productLinks.add(fullUrl);
                    }
                }
            });
            if (productLinks.size > 0) {
                log.info(`Tìm thấy ${productLinks.size} link sản phẩm với selector: ${selector}`);
                break;
            }
        }
        for (const url of productLinks) {
            productItems.push({ url, thumbnail: '' });
        }
    }

    log.info(`Tổng cộng tìm thấy ${productItems.length} sản phẩm.`);

    if (productItems.length > 0) {
        // Enqueue từng link sản phẩm kèm thumbnail
        for (const item of productItems) {
            await enqueueLinks({
                urls: [item.url],
                label: 'hgcstone-detail',
                strategy: 'same-domain',
                userData: { thumbnail: item.thumbnail }
            });
        }

        // Logic phân trang - xử lý cả format page/{số} và query parameter
        let currentPage = 1;
        let nextPageUrl = '';

        // Kiểm tra format page/{số} trong URL
        const pageMatch = url.match(/\/page\/(\d+)\/?$/);
        if (pageMatch) {
            currentPage = parseInt(pageMatch[1], 10);
        } else {
            // Fallback: kiểm tra query parameter
            const urlObj = new URL(url);
            currentPage = parseInt(urlObj.searchParams.get('page') || '1', 10);
        }

        if (currentPage < config.pageEnd) {
            const nextPage = currentPage + 1;

            // Tạo URL trang tiếp theo
            if (url.includes('/page/')) {
                // Format: thay thế /page/{số}/ bằng /page/{số+1}/
                nextPageUrl = url.replace(/\/page\/\d+\/?$/, `/page/${nextPage}/`);
            } else {
                // Format: thêm /page/{số}/ vào cuối URL
                const baseUrl = url.endsWith('/') ? url : url + '/';
                nextPageUrl = baseUrl + `page/${nextPage}/`;
            }

            log.info(`Enqueue trang tiếp theo: ${nextPageUrl} (trang ${nextPage}/${config.pageEnd})`);
            await enqueueLinks({ urls: [nextPageUrl] });
        } else {
            log.info(`Đã đạt giới hạn trang tối đa (${config.pageEnd}). Dừng phân trang.`);
        }
    } else {
        log.info('Không tìm thấy link sản phẩm nào. Có thể đã hết trang hoặc cấu trúc website thay đổi.');
    }
});

// Handler chi tiết sản phẩm
router.addHandler('hgcstone-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ HGC Stone Detail: ${url}`);

    // Bỏ qua URL chỉ có /san-pham/ mà không có thêm path
    if (url === 'https://www.hgcstone.vn/san-pham/' || url.endsWith('/san-pham/')) {
        log.info('Bỏ qua URL chỉ có /san-pham/ mà không có thêm path.');
        return;
    }

    try {
        // Title: lấy từ h1 với class product_title entry-title (như trong ảnh)
        let title = $('h1.product_title.entry-title').first().text().trim();
        if (!title) {
            // Fallback: h1 với itemprop="name"
            title = $('h1[itemprop="name"]').first().text().trim();
        }
        if (!title) {
            // Fallback: h1 thường
            title = $('h1').first().text().trim();
        }
        if (!title) {
            log.info('Bỏ qua sản phẩm vì không có title.');
            return;
        }

        // Description: lấy từ meta description
        let description = $('meta[name="description"]').attr('content') || '';
        if (!description) {
            // Fallback: lấy từ .product-description
            description = $('.product-description').first().text().trim();
        }
        if (!description) {
            // Fallback: lấy từ .description
            description = $('.description').first().text().trim();
        }

        // Price: lấy từ các selector giá
        let price = $('.price').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
        if (!price) {
            price = $('.product-price').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
        }
        if (!price) {
            price = $('.new-price').first().text().replace(/[^\d.,]/g, '').replace(/\.+$/, '').trim();
        }

        // SKU: lấy từ ID sản phẩm (như 144 từ product-144) và tạo format HGC-144
        let sku = ''; // Default value
        const productDiv = $('div[id^="product-"]').first();
        if (productDiv.length) {
            const productId = productDiv.attr('id');
            if (productId) {
                const match = productId.match(/product-(\d+)/);
                if (match && match[1]) {
                    sku = `HGC-${match[1]}`;
                }
            }
        }

        // Categories: lấy từ breadcrumb hoặc category links
        let categories = [];
        $('.breadcrumb a, .category a, .product-category a').each(function (i, el) {
            const txt = $(el).text().trim();
            if (txt && txt !== 'Trang chủ' && txt !== 'Home') {
                categories.push(txt);
            }
        });

        // Tags: lấy từ tag links
        let tags = [];
        $('.product-tags a, .tags a').each(function (i, el) {
            const txt = $(el).text().trim();
            if (txt) tags.push(txt);
        });

        // Images: lọc ảnh dựa trên phần cuối URL sản phẩm
        let images = [];
        // Lấy phần cuối URL sản phẩm (như /gach-the-vang-chay-gt11)
        const urlParts = url.split('/');
        const productSlug = urlParts[urlParts.length - 2] || ''; // Lấy phần trước cuối cùng

        if (productSlug) {
            $('img').each(function (i, el) {
                const src = $(el).attr('src');
                if (src &&
                    !/logo/i.test(src) &&
                    !/footer/i.test(src) &&
                    !/banner/i.test(src) &&
                    !/header/i.test(src) &&
                    src.toLowerCase().includes(productSlug.toLowerCase()) &&
                    src.includes('600x')) {
                    images.push(src);
                }
            });
        }

        images = Array.from(new Set(images)); // Loại bỏ duplicate

        // Content: lấy từ class="untabs" như trong ảnh
        let content = $('.untabs').html() || '';
        if (!content) {
            // Fallback: lấy từ các selector khác
            content = $('.product-description').html() || '';
        }
        if (!content) {
            content = $('.description').html() || '';
        }
        if (!content) {
            content = $('.product-details').html() || '';
        }
        content = he.decode(content);
        content = formatContent(content, 'hgcstone');

        // Thumbnail: lấy từ userData nếu có, nếu không thì fallback
        let thumbnail = request.userData && request.userData.thumbnail ? request.userData.thumbnail : '';
        if (!thumbnail) {
            const thumbImg = $('.product-image img, .product-thumb img').first();
            if (thumbImg.length) {
                thumbnail = thumbImg.attr('src') || '';
            }
        }

        const productData = {
            sku,
            url,
            title,
            description,
            price,
            categories,
            tags,
            thumbnail,
            images,
            content,
            supplier: 'HGC Stone',
            url_supplier: 'https://www.hgcstone.vn'
        };

        pushData(productData);
        addScrapedData(productData);
        log.info(`Đã lấy xong dữ liệu sản phẩm: ${title}`);

    } catch (err) {
        log.error('Error in hgcstone-detail handler:', err.message);
    }

    await sleep(createRandomSleep(config.delayMin, config.delayMax));
}); 