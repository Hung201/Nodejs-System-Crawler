import { createCheerioRouter, sleep } from 'crawlee';
import { formatContent } from '../helpers/content-helper.js';
import { addScrapedData } from '../helpers/data-saver.js';
import he from 'he';

export const config = {
    pageStart: 1,
    pageEnd: 50, // Giới hạn tối đa 50 trang để tránh lặp vô hạn
    delayMin: 300,
    delayMax: 800,
};

export const router = createCheerioRouter();

// Handler danh mục: lấy tất cả link sản phẩm, phân trang, chỉ lấy tối đa 20 sản phẩm
router.addDefaultHandler(async ({ request, enqueueLinks, $, log }) => {
    const url = request.loadedUrl;
    log.info(`+ GCCKH Category: ${url}`);
    const productLinks = new Set();
    // Lấy tất cả link sản phẩm có dạng https://gachcaocapkhanhhuyen.com/san-pham/ten-san-pham
    $('a').each(function (i, el) {
        const href = $(el).attr('href');
        if (href && /^https:\/\/gachcaocapkhanhhuyen.com\/san-pham\/[a-zA-Z0-9\-_/]+\/?$/.test(href) && !href.includes('/page/')) {
            productLinks.add(href);
        }
    });
    log.info(`Tìm thấy ${productLinks.size} link sản phẩm.`);
    if (productLinks.size > 0) {
        await enqueueLinks({
            label: 'gcckh-detail',
            strategy: 'same-domain',
            urls: Array.from(productLinks)
        });
    }
    // Phân trang: tự động tăng /page/2, /page/3,... đến tối đa 72 trang, giữ nguyên query string nếu có
    const urlObj = new URL(url);
    const pageMatch = urlObj.pathname.match(/\/page\/(\d+)/);
    let currentPage = pageMatch ? parseInt(pageMatch[1], 10) : 1;
    if (currentPage < config.pageEnd) {
        const nextPage = currentPage + 1;
        let nextPath = '';
        if (urlObj.pathname.includes('/page/')) {
            nextPath = urlObj.pathname.replace(/\/page\/(\d+)/, `/page/${nextPage}`);
        } else {
            nextPath = urlObj.pathname.endsWith('/') ? urlObj.pathname + `page/${nextPage}/` : urlObj.pathname + `/page/${nextPage}/`;
        }
        urlObj.pathname = nextPath;
        const nextPageUrl = urlObj.toString();
        log.info(`Enqueue trang tiếp theo: ${nextPageUrl}`);
        await enqueueLinks({ urls: [nextPageUrl] });
    }
});

// Handler chi tiết sản phẩm
router.addHandler('gcckh-detail', async ({ request, $, log, pushData }) => {
    const url = request.loadedUrl;
    log.info(`+ GCCKH Detail: ${url}`);
    // Lấy title
    const title = $('h1.product-title, h1.product_title, h1.entry-title, h1').first().text().trim();
    if (!title) {
        log.info('Bỏ qua sản phẩm vì không có title.');
        return;
    }
    // Lấy sku từ title (mã cuối cùng trong title, ví dụ TQ-212940)
    let sku = '';
    const skuMatch = title.match(/([A-Z0-9\-]+)$/i);
    if (skuMatch) sku = 'GCCKH-' + skuMatch[1];
    // Lấy thumbnail và images
    let images = [];
    let thumbnail = '';
    // Lấy ảnh đầu tiên trong gallery (chỉ lấy ảnh có 600x600, bỏ qua svg)
    const mainImg = $('.wp-post-image, .woocommerce-product-gallery__image img, .zoomImg, .woocommerce-product-gallery img').filter(function () {
        const src = $(this).attr('src');
        return src && !src.startsWith('data:image/svg+xml') && !src.includes('100x100');
    }).first();
    if (mainImg.length) {
        thumbnail = mainImg.attr('src') || '';
    }
    // Nếu không có thumbnail thì bỏ qua sản phẩm
    if (!thumbnail) {
        log.info('Bỏ qua sản phẩm vì không có thumbnail.');
        return;
    }
    // Lấy tất cả ảnh gallery, chỉ lấy ảnh có 600x600, bỏ qua ảnh svg
    $('.wp-post-image, .woocommerce-product-gallery__image img, .zoomImg, .woocommerce-product-gallery img').each(function (i, el) {
        const src = $(el).attr('src');
        if (src && !src.startsWith('data:image/svg+xml') && src.includes('600') && !images.includes(src)) images.push(src);
    });
    // Lấy content mô tả
    let content = $('.woocommerce-Tabs-panel.woocommerce-Tabs-panel--description.panel.entry-content.active').first().html() || '';
    content = he.decode(content);
    content = formatContent(content, 'gcckh');
    // Lấy giá nếu có
    let price = $('.price, .woocommerce-Price-amount').first().text().trim();
    // Push data
    const productData = {
        url,
        title,
        sku,
        price,
        thumbnail,
        images,
        content,
        supplier: 'Gạch Cao Cấp Khánh Huyền',
        url_supplier: 'https://gachcaocapkhanhhuyen.com/'
    };
    pushData(productData);
    addScrapedData(productData);
    log.info(`Đã lấy xong dữ liệu sản phẩm: ${title}`);
    await sleep(Math.floor(Math.random() * (config.delayMax - config.delayMin + 1)) + config.delayMin);
}); 