import axios from 'axios';

/**
 * Gửi HTML danh mục lên Gemini AI để sinh selector tự động
 * @param {string} html - HTML của trang danh mục
 * @returns {Promise<{productLinkSelector: string, paginationSelector: string}>}
 */
export async function getSelectorsByGemini(html) {
    const prompt = `Bạn là AI crawler DOM. Dưới đây là HTML của một trang danh mục sản phẩm.\n\nHãy trả về một JSON có dạng:\n{\n  "productLinkSelector": "...",\n  "paginationSelector": "..."\n}\n\nHTML:\n${html.substring(0, 20000)}`;

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error('Missing GEMINI_API_KEY');

    const response = await axios.post(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent',
        { contents: [{ parts: [{ text: prompt }] }] },
        { headers: { 'Content-Type': 'application/json' }, params: { key: apiKey } }
    );

    let aiOutput = response.data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    // Loại bỏ markdown nếu có
    aiOutput = aiOutput.replace(/```json|```/gi, '').trim();
    try {
        return JSON.parse(aiOutput);
    } catch (e) {
        throw new Error('Gemini không trả về JSON selector hợp lệ: ' + aiOutput);
    }
} 