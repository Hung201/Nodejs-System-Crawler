const alibabaStyle = `
    <style>
        #detail_decorate_root .magic-0 {
            border-bottom-style: solid;
            border-bottom-color: #53647a;
            font-size: 24px;
            color: #53647a;
            font-style: normal;
            border-bottom-width: 2px;
            padding-top: 8px;
            padding-bottom: 4px;
        }
        #detail_decorate_root img {
            max-width: 100%;
        }
    </style>
`;

const inaxStyle = `
    <style>
    body {
        font-family: 'Roboto', Arial, sans-serif;
        background: #fff;
        color: #222;
        margin: 0;
        padding: 0;
        padding-right: 20%;
        padding-left: 20%;
    }

    .title-1 {
        font-size: 36px;
        font-weight: bold;
        color: #222;
        text-align: center;
        margin-top: 40px;
        margin-bottom: 32px;
        letter-spacing: 2px;
    }

    .title {
        font-size: 22px;
        font-weight: 500;
        color: #009fe3;
        border-left: 5px solid #009fe3;
        padding-left: 12px;
        margin-bottom: 18px;
        margin-top: 24px;
    }

    .size-pro {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 8px;
    }

    .size-pro td {
        padding: 6px 12px;
        font-size: 16px;
        color: #333;
    }

    .size-pro strong {
        color: #222;
    }

    .row {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 24px;
    }

    .col-md-6,
    .col-sm-8 {
        flex: 1;
        min-width: 280px;
        margin-right: 24px;
    }

    .features-text-bullet {
        margin-top: 12px;
    }

    .features-bullet {
        list-style: disc inside;
        color: #555;
        font-size: 16px;
        line-height: 1.8;
        padding-left: 18px;
    }

    .features-bullet li {
        margin-bottom: 6px;
    }
</style>
`;

const unknownStyle = `
<style>
font-family: 'Segoe UI', Arial, sans-serif;
    background: #fff;
    color: #222;
    padding: 20px;
    max-width: 900px;
    margin: 0 auto;
    line-height: 1.6;
</style>
`;

const tongkhokeodanStyle = `
<style>
.tkd-content-root {
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #fff;
    color: #222;
    padding: 0 8vw 2vw 8vw;
    max-width: 900px;
    margin: 0 auto;
}
.tkd-content-root h1, .tkd-content-root h2, .tkd-content-root h3 {
    color: #1a4d8f;
    font-weight: bold;
    margin-top: 2em;
    margin-bottom: 0.7em;
}
.tkd-content-root h1 { font-size: 2.2em; }
.tkd-content-root h2 { font-size: 1.5em; border-bottom: 2px solid #1a4d8f; padding-bottom: 0.2em; }
.tkd-content-root h3 { font-size: 1.2em; }
.tkd-content-root p { font-size: 1.05em; line-height: 1.7; margin-bottom: 1em; }
.tkd-content-root ul, .tkd-content-root ol { margin-left: 1.5em; margin-bottom: 1em; }
.tkd-content-root li { margin-bottom: 0.5em; }
.tkd-content-root table { border-collapse: collapse; width: 100%; margin: 1.5em 0; background: #f8fafc; }
.tkd-content-root th, .tkd-content-root td { border: 1px solid #dbeafe; padding: 8px 12px; text-align: left; }
.tkd-content-root th { background: #e0e7ef; color: #1a4d8f; font-weight: 600; }
.tkd-content-root tr:nth-child(even) { background: #f1f5f9; }
.tkd-content-root strong { color: #1a4d8f; }
.tkd-content-root img { max-width: 100%; border-radius: 6px; margin: 1em 0; box-shadow: 0 2px 8px #0001; }
.tkd-content-root a { color: #1a4d8f; text-decoration: underline; }
@media (max-width: 700px) {
    .tkd-content-root { padding: 0 2vw; }
    .tkd-content-root table, .tkd-content-root th, .tkd-content-root td { font-size: 0.95em; }
}
</style>
`;

const ecobiglaziotileStyle = `
<style>
.ecobiglaziotile-content-root {
    font-family: Arial, Helvetica, sans-serif;
    background: #fff;
    color: #222;
    padding: 0 8vw 2vw 8vw;
    max-width: 1000px;
    margin: 0 auto;
}
.ecobiglaziotile-content-root h1, .ecobiglaziotile-content-root h2, .ecobiglaziotile-content-root h3 {
    color: #1a4d8f;
    font-weight: bold;
    margin-top: 2em;
    margin-bottom: 0.7em;
}
.ecobiglaziotile-content-root h1 { font-size: 2.2em; }
.ecobiglaziotile-content-root h2 { font-size: 1.5em; border-bottom: 2px solid #1a4d8f; padding-bottom: 0.2em; }
.ecobiglaziotile-content-root h3 { font-size: 1.2em; }
.ecobiglaziotile-content-root p { font-size: 1.05em; line-height: 1.7; margin-bottom: 1em; text-align: justify; }
.ecobiglaziotile-content-root ul, .ecobiglaziotile-content-root ol { margin-left: 1.5em; margin-bottom: 1em; }
.ecobiglaziotile-content-root li { margin-bottom: 0.5em; }
.ecobiglaziotile-content-root table { border-collapse: collapse; width: 100%; margin: 1.5em 0; background: #f8fafc; }
.ecobiglaziotile-content-root th, .ecobiglaziotile-content-root td { border: 1px solid #dbeafe; padding: 8px 12px; text-align: left; font-size: 16px; }
.ecobiglaziotile-content-root th { background: #e0e7ef; color: #1a4d8f; font-weight: 600; }
.ecobiglaziotile-content-root tr:nth-child(even) { background: #f1f5f9; }
.ecobiglaziotile-content-root strong { color: #1a4d8f; }
.ecobiglaziotile-content-root img { max-width: 100%; border-radius: 6px; margin: 1em 0; box-shadow: 0 2px 8px #0001; display: block; margin-left: auto; margin-right: auto; }
.ecobiglaziotile-content-root a { color: #1a4d8f; text-decoration: underline; }
.ecobiglaziotile-content-root .ck-content { padding: 0; background: none; }
@media (max-width: 700px) {
    .ecobiglaziotile-content-root { padding: 0 2vw; }
    .ecobiglaziotile-content-root table, .ecobiglaziotile-content-root th, .ecobiglaziotile-content-root td { font-size: 0.95em; }
}
</style>
`;

const daisanhouseStyle = `<style></style>`;

const grandceramicStyle = `<style></style>`;

const mosaichouseStyle = `
<style>
.bg-ms-product {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 8px #0001;
    padding: 24px 18px 32px 18px;
    margin: 0 auto 32px auto;
    max-width: 900px;
    font-family: 'Segoe UI', Arial, sans-serif;
    color: #222;
}
.bg-ms-product .nav-tabs {
    border-bottom: 2px solid #e5e5e5;
    margin-bottom: 18px;
}
.bg-ms-product .nav-tabs > li > a {
    color: #222;
    font-weight: bold;
    font-size: 15px;
    border: none;
    border-radius: 0;
    background: none;
}
.bg-ms-product .nav-tabs > li.active > a {
    color: #007bff;
    border-bottom: 2px solid #007bff;
    background: none;
}
.bg-ms-product .tab-content {
    padding: 0 8px;
}
.bg-ms-product h2, .bg-ms-product h3 {
    color: #c0392b;
    font-size: 18px;
    margin-top: 18px;
    margin-bottom: 12px;
}
.bg-ms-product p, .bg-ms-product span, .bg-ms-product li {
    font-size: 15px;
    line-height: 1.7;
    color: #222;
}
.bg-ms-product img {
    display: block;
    margin: 18px auto;
    max-width: 100%;
    border-radius: 6px;
    box-shadow: 0 2px 8px #0002;
}
.bg-ms-product .tab-pane {
    min-height: 60px;
}
.bg-ms-product strong {
    color: #c0392b;
}
.bg-ms-product ul {
    margin-left: 1.2em;
    margin-bottom: 1em;
}
.bg-ms-product li {
    margin-bottom: 0.5em;
}
.bg-ms-product .bottom20 {
    margin-bottom: 20px;
}
@media (max-width: 700px) {
    .bg-ms-product { padding: 8px 2vw; }
}
</style>
`;

const newlandoStyle = `
<style>

</style>
`;

const hgcstoneStyle = `
<style>
* {
        font-family: Arial, sans-serif;
        color: #333;
        line-height: 1.6;
        font-size: 16px;
        width: 75%;
    }

    h2 {
        font-size: 20px;
        font-weight: bold;
        color: #b32d2e;
        /* màu đỏ tương tự ảnh */
        text-transform: uppercase;
        margin-bottom: 8px;
        border-bottom: 1px solid #ccc;
        padding-bottom: 4px;
    }

    p {
        margin: 12px 0;
    }

    a {
        text-decoration: none;
        color: #464646;
    }

    img {
        display: block;
        margin: 16px auto;
        max-width: 100%;
        height: auto;
    }
</style>
`;

const starkStyle = `<style></style>`;

const taiceravnStyle = `<style></style>`;

const totoStyle = `<style></style>`;

const innomatStyle = `<style></style>`;

const gcckhStyle = `<style></style>`;

const lecaoStyle = `<style></style>`;

export const formatContent = (content, type = 'alibaba') => {
    // remove noscript, default style
    content = content.replace(/(<noscript>.*<\/noscript>)|(<style>.*<\/style>)/gi, '');

    // convert data-src to src
    content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');

    // add custom style
    if (type === 'inax') {
        return inaxStyle + content;
    }
    if (type === 'unknown') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*<\/noscript>)|(<style>.*<\/style>)/gi, '');
        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return unknownStyle + `<div class="unknown-content-root">` + content + `</div>`;
    }
    if (type === 'tongkhokeodan') {
        return tongkhokeodanStyle + `<div class="tkd-content-root">` + content + `</div>`;
    }
    if (type === 'ecobiglaziotile') {
        content = content.replace(/(<noscript>.*?<\/noscript>)|(<style>.*?<\/style>)/gis, '');
        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return ecobiglaziotileStyle + `<div class="ecobiglaziotile-content-root">` + content + `</div>`;
    }
    if (type === 'daisanhouse') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*?<\/noscript>)|(<style>.*?<\/style>)/gis, '');

        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return daisanhouseStyle + `<div class="daisanhouse-content-root">` + content + `</div>`;
    }
    if (type === 'grandceramic') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*?<\/noscript>)|(<style>.*?<\/style>)/gis, '');

        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return grandceramicStyle + content;
    }
    if (type === 'mosaichouse') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*?<\/noscript>)|(<style>.*?<\/style>)/gis, '');
        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return mosaichouseStyle + `<div class="bg-ms-product">` + content + `</div>`;
    }
    if (type === 'newlando') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*<\/noscript>)|(<style>.*<\/style>)/gi, '');

        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return newlandoStyle + `<div class="newlando-content-root">` + content + `</div>`;
    }
    if (type === 'hgcstone') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*<\/noscript>)|(<style>.*<\/style>)/gi, '');

        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return hgcstoneStyle + `<div class="hgcstone-content-root">` + content + `</div>`;
    }
    if (type === 'stark') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*<\/noscript>)|(<style>.*<\/style>)/gi, '');

        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return starkStyle + `<div class="stark-content-root">` + content + `</div>`;
    }
    if (type === 'taiceravn') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*<\/noscript>)|(<style>.*<\/style>)/gi, '');
        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return taiceravnStyle + `<div class="taiceravn-content-root">` + content + `</div>`;
    }
    if (type === 'toto') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*<\/noscript>)|(<style>.*<\/style>)/gi, '');
        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return totoStyle + `<div class="toto-content-root">` + content + `</div>`;
    }
    if (type === 'innomat') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*<\/noscript>)|(<style>.*<\/style>)/gi, '');
        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return innomatStyle + `<div class="innomat-content-root">` + content + `</div>`;
    }
    if (type === 'gcckh') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*<\/noscript>)|(<style>.*<\/style>)/gi, '');
        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return gcckhStyle + `<div class="gcckh-content-root">` + content + `</div>`;
    }
    if (type === 'lecao') {
        // remove noscript, default style
        content = content.replace(/(<noscript>.*?<\/noscript>)|(<style>.*?<\/style>)/gis, '');
        // convert data-src to src
        content = content.replace(/src="[^"]+"\s+data-src="([^"]+)"/g, 'src="$1"');
        return lecaoStyle + `<div class="lecao-content-root">` + content + `</div>`;
    }
    return alibabaStyle + content;
};