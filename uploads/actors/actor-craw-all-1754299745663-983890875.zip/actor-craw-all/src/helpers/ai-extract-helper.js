import OpenAI from 'openai';

const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Trích xuất dữ liệu sản phẩm từ HTML bằng AI.
 * @param {string} html - HTML của trang sản phẩm
 * @param {object} options - { url, supplier, url_supplier }
 * @returns {object} { url, sku, title, price, thumbnail, images, supplier, url_supplier, content }
 */
export async function extractProductByAI(html, options = {}) {
        const { url = '', supplier = 'Unknown', url_supplier = '' } = options;
        const prompt = `Bạn là một AI chuyên trích xuất dữ liệu sản phẩm từ HTML. Hãy đọc đoạn HTML sau và trả về JSON với các trường: url, sku, title, price, thumbnail, images (mảng), supplier, url_supplier, content. Nếu không có trường nào thì để chuỗi rỗng hoặc mảng rỗng. Chỉ trả về JSON, không giải thích gì thêm.\nHTML:\n${html}`;
        const response = await openai.chat.completions.create({
                model: 'gpt-3.5-turbo',
                messages: [
                        { role: 'system', content: 'Bạn là AI chuyên trích xuất dữ liệu sản phẩm từ HTML.' },
                        { role: 'user', content: prompt }
                ],
                temperature: 0.2,
                max_tokens: 1000
        });
        // Lấy JSON từ response
        const text = response.choices[0].message.content;
        let result;
        try {
                result = JSON.parse(text);
        } catch (e) {
                return { error: 'AI không trả về JSON hợp lệ', raw: text };
        }
        // Bổ sung các trường còn thiếu
        return {
                url: result.url || url,
                sku: result.sku || '',
                title: result.title || '',
                price: result.price || '',
                thumbnail: result.thumbnail || '',
                images: Array.isArray(result.images) ? result.images : [],
                supplier: result.supplier || supplier,
                url_supplier: result.url_supplier || url_supplier,
                content: result.content || ''
        };
} 