export const WEBSITE_TYPES = {
        ALIBABA: 'alibaba',
        INAX: 'inax',
        TONGKHO_KEODAN: 'tongkhokeodan',
        ECOBIGLAZIOTILE: 'ecobiglaziotile',
        DAISANSTORE: 'daisanhouse',
        MOSAICHOUSE: 'mosaichouse',
        UNKNOWN: 'unknown',
        GRANDCERAMICS: 'grandceramics',
        NEWLANDO: 'newlando',
        TASACERAMIC: 'tasaceramic',
        SHOPEE: 'shopee',
        HGCSTONE: 'hgcstone',
        STARK: 'stark',
        TAICERAVN: 'taiceravn',
        LECAOPHATTILES: 'lecaophattiles',
        TOTO: 'toto',
        INNOMAT: 'innomat',
        GCCKH: 'gcckh',
};

export const detectWebsiteType = (url) => {
        const domain = getDomain(url);

        if (domain.includes('alibaba.com')) {
                return WEBSITE_TYPES.ALIBABA;
        }

        if (domain.includes('inax.com') || domain.includes('inax.co.jp') || domain.includes('inax.com.vn')) {
                return WEBSITE_TYPES.INAX;
        }

        if (domain.includes('tongkhokeodan.com')) {
                return WEBSITE_TYPES.TONGKHO_KEODAN;
        }

        if (domain.includes('ecobiglaziotile.com')) {
                return WEBSITE_TYPES.ECOBIGLAZIOTILE;
        }

        if (domain.includes('daisanhouse.vn')) {
                return WEBSITE_TYPES.DAISANSTORE;
        }

        if (domain.includes('mosaichouse.vn')) {
                return WEBSITE_TYPES.MOSAICHOUSE;
        }

        if (domain.includes('grandceramics.vn')) {
                return WEBSITE_TYPES.GRANDCERAMICS;
        }

        if (domain.includes('newlando.vn')) {
                return WEBSITE_TYPES.NEWLANDO;
        }

        if (domain.includes('tasaceramic.vn')) {
                return WEBSITE_TYPES.TASACERAMIC;
        }

        if (domain.includes('shopee.vn')) {
                return WEBSITE_TYPES.SHOPEE;
        }

        if (domain.includes('hgcstone.vn')) {
                return WEBSITE_TYPES.HGCSTONE;
        }

        if (domain.includes('stark.com.vn')) {
                return WEBSITE_TYPES.STARK;
        }

        if (domain.includes('taiceravn.com')) {
                return WEBSITE_TYPES.TAICERAVN;
        }

        if (domain.includes('lecaophattiles.vn')) {
                return WEBSITE_TYPES.LECAOPHATTILES;
        }

        if (domain.includes('vn.toto.com')) {
                return WEBSITE_TYPES.TOTO;
        }

        if (domain.includes('innomat.vn')) {
                return WEBSITE_TYPES.INNOMAT;
        }

        if (domain.includes('gachcaocapkhanhhuyen.com')) {
                return WEBSITE_TYPES.GCCKH;
        }

        return WEBSITE_TYPES.UNKNOWN;
};

export const getDomain = (url) => {
        try {
                const urlParse = new URL(url);
                return urlParse.hostname;
        }
        catch (e) {
                return '';
        }
}; 