import puppeteer from 'puppeteer';

export async function getImagesWithPuppeteer(url) {
    const browser = await puppeteer.launch({ headless: true });
    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'networkidle2' });

    // Đợi selector xuất hiện (tối đa 10s, không lỗi nếu không có)
    await page.waitForSelector('img', { timeout: 10000 }).catch(() => { });

    // Đợi thêm cho JS render (nếu cần)
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Scroll xuống cuối trang để kích hoạt lazy-load (nếu có)
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Lấy tất cả src ảnh trên trang có pattern đúng
    const images = await page.$$eval('img', imgs =>
        imgs
            .map(img => img.getAttribute('src'))
            .filter(src =>
                src &&
                (src.startsWith('/pictures/files/san-pham/') ||
                    src.startsWith('https://grandceramics.vn/pictures/files/san-pham/'))
            )
            .map(src =>
                src.startsWith('/pictures/files/san-pham/')
                    ? 'https://grandceramics.vn' + src
                    : src
            )
    );


    await browser.close();
    return images;
} 