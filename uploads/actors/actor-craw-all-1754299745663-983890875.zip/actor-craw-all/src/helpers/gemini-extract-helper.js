import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

export async function extractProductByGemini(html, options = {}) {
    const { url = '', supplier = 'Unknown', url_supplier = '', model = 'gemini-pro' } = options;
    const prompt = `
Bạn là AI chuyên trích xuất dữ liệu sản phẩm từ HTML. 
Hãy đọc kỹ toàn bộ HTML sau và trả về JSON với các trường: 
url, sku, title, price, thumbnail, images (mảng), supplier, url_supplier, content. 
- Nếu không tìm thấy trường nào, để giá trị rỗng hoặc mảng rỗng.
- Đọc kỹ cả các thẻ <title>, <meta>, <h1>, <h2>, <img>, <span>, <div>, <p>, và các class/id phổ biến như product, price, name, sku, description, content, image, gallery.
- Không giải thích gì thêm, chỉ trả về JSON hợp lệ.
HTML:
${html}
`;
    const geminiModel = genAI.getGenerativeModel({ model });
    const result = await geminiModel.generateContent(prompt);
    const text = result.response.text();
    let parsed;
    try {
        parsed = JSON.parse(text);
    } catch (e) {
        return { error: 'Gemini không trả về JSON hợp lệ', raw: text };
    }
    // Bổ sung các trường còn thiếu
    return {
        url: parsed.url || url,
        sku: parsed.sku || '',
        title: parsed.title || '',
        price: parsed.price || '',
        thumbnail: parsed.thumbnail || '',
        images: Array.isArray(parsed.images) ? parsed.images : [],
        supplier: parsed.supplier || supplier,
        url_supplier: parsed.url_supplier || url_supplier,
        content: parsed.content || ''
    };
} 